<?php
class Deux_Shortcode_Partner extends WP_Shortcode_UI
{
	public $shortcode_name = 'partners';

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * render the output of shotcode
	 * @param  array $atts
	 * @param  string $content
	 * @return mixed
	 */
	public function render( $atts, $content = null ){
		$atts = shortcode_atts( array(
			'source'              => 'media_library',
			'images'              => '',
			'custom_srcs'         => '',
			'image_size'          => 'full',
			'external_img_size'   => '',
			'custom_links'        => '',
			'custom_links_target' => '_self',
			'layout'              => 'bordered',
			'css_animation'       => '',
			'el_class'            => '',
		), $atts );

		$css_class     = array(
			'deux-partners',
			$atts['layout'] . '-layout',
			$atts['el_class'],
		);
		$css_animation = $this->get_css_animation( $atts['css_animation'] );
		$images        = $logos = array();
		$custom_links  = explode( ',', vc_value_from_safe( $atts['custom_links'] ) );
		$default_src   = vc_asset_url( 'vc/no_image.png' );

		switch ( $atts['source'] ) {
			case 'media_library':
				$images = explode( ',', $atts['images'] );
				break;

			case 'external_link':
				$images = vc_value_from_safe( $atts['custom_srcs'] );
				$images = explode( ',', $images );

				break;
		}

		foreach ( $images as $i => $image ) {
			$thumbnail = '';

			switch ( $atts['source'] ) {
				case 'media_library':
					if ( $image > 0 ) {
						$img       = wpb_getImageBySize( array(
							'attach_id'  => $image,
							'thumb_size' => $atts['image_size'],
						) );
						$thumbnail = $img['thumbnail'];
					} else {
						$thumbnail = '<img src="' . $default_src . '" />';
					}
					break;

				case 'external_link':
					$image      = esc_attr( $image );
					$dimensions = vcExtractDimensions( $atts['external_img_size'] );
					$hwstring   = $dimensions ? image_hwstring( $dimensions[0], $dimensions[1] ) : '';
					$thumbnail  = '<img ' . $hwstring . ' src="' . $image . '" />';
					break;
			}

			if ( empty( $custom_links[ $i ] ) ) {
				$logo = '<span class="partner-logo">' . $thumbnail . '</span>';
			} else {
				$logo = sprintf( '<a href="%s" target="%s" class="partner-logo">%s</a>', esc_url( $custom_links[ $i ] ), esc_attr( $atts['custom_links_target'] ), $thumbnail );
			}

			$logos[] = '<div class="partner' . esc_attr( $css_animation ) . '">' . $logo . '</div>';
		}

		return sprintf( '<div class="%s">%s</div>', esc_attr( implode( ' ', $css_class ) ), implode( ' ', $logos ) );
	}

	/**
	 * render to visual composer
	 * @return mixed
	 */
	public function mapping(){
		vc_map( array(
			'name'        => esc_html__( 'Partner Logos', 'deux' ),
			'description' => esc_html__( 'Show list of partner logo', 'deux' ),
			'base'        => 'deux_partners',
			'category'    => esc_html__( 'Deux', 'deux' ),
			'params'      => array(
				array(
					'heading'     => esc_html__( 'Image source', 'deux' ),
					'description' => esc_html__( 'Select images source', 'deux' ),
					'type'        => 'dropdown',
					'param_name'  => 'source',
					'value'       => array(
						esc_html__( 'Media library', 'deux' )  => 'media_library',
						esc_html__( 'External Links', 'deux' ) => 'external_link',
					),
				),
				array(
					'heading'     => esc_html__( 'Images', 'deux' ),
					'description' => esc_html__( 'Select images from media library', 'deux' ),
					'type'        => 'attach_images',
					'param_name'  => 'images',
					'dependency'  => array(
						'element' => 'source',
						'value'   => 'media_library',
					),
				),
				array(
					'heading'     => esc_html__( 'Image size', 'deux' ),
					'description' => esc_html__( 'Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)). Leave empty to use "thumbnail" size.', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'img_size',
					'dependency'  => array(
						'element' => 'source',
						'value'   => 'media_library',
					),
				),
				array(
					'heading'     => esc_html__( 'External links', 'deux' ),
					'description' => esc_html__( 'Enter external links for partner logos (Note: divide links with linebreaks (Enter)).', 'deux' ),
					'type'        => 'exploded_textarea_safe',
					'param_name'  => 'custom_srcs',
					'dependency'  => array(
						'element' => 'source',
						'value'   => 'external_link',
					),
				),
				array(
					'heading'     => esc_html__( 'Image size', 'deux' ),
					'description' => esc_html__( 'Enter image size in pixels. Example: 200x100 (Width x Height).', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'external_img_size',
					'dependency'  => array(
						'element' => 'source',
						'value'   => 'external_link',
					),
				),
				array(
					'heading'     => esc_html__( 'Custom links', 'deux' ),
					'description' => esc_html__( 'Enter links for each image here. Divide links with linebreaks (Enter).', 'deux' ),
					'type'        => 'exploded_textarea_safe',
					'param_name'  => 'custom_links',
				),
				array(
					'heading'     => esc_html__( 'Custom link target', 'deux' ),
					'description' => esc_html__( 'Select where to open custom links.', 'deux' ),
					'type'        => 'dropdown',
					'param_name'  => 'custom_links_target',
					'value'       => array(
						esc_html__( 'Same window', 'deux' ) => '_self',
						esc_html__( 'New window', 'deux' )  => '_blank',
					),
				),
				array(
					'heading'     => esc_html__( 'Layout', 'deux' ),
					'description' => esc_html__( 'Select the layout images source', 'deux' ),
					'type'        => 'dropdown',
					'param_name'  => 'layout',
					'value'       => array(
						esc_html__( 'Bordered', 'deux' )  => 'bordered',
						esc_html__( 'Plain', 'deux' ) => 'plain',
					),
				),
				vc_map_add_css_animation(),
				array(
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
					'param_name'  => 'el_class',
					'type'        => 'textfield',
				),
			),
		) );
	}
}


new Deux_Shortcode_Partner();