<?php
class Deux_Shortcode_Faq extends WP_Shortcode_UI
{
	public $shortcode_name = 'faq';

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * render the output of shotcode
	 * @param  array $atts
	 * @param  string $content
	 * @return mixed
	 */
	public function render( $atts, $content = null ){
		$atts = shortcode_atts( array(
			'title'         => esc_html__( 'Question content goes here', 'deux' ),
			'open'          => 'false',
			'css_animation' => '',
			'el_class'      => '',
		), $atts );

		$css_class = array(
			'deux-faq',
			$this->get_css_animation( $atts['css_animation'] ),
			$atts['el_class'],
		);

		if ( 'true' == $atts['open'] ) {
			$css_class[] = 'open';
		}

		return sprintf(
			'<div class="%s">
				<div class="question">
					<span class="question-label">%s</span>
					<span class="question-icon"><span class="toggle-icon"></span></span>
					<span class="question-title">%s</span>
				</div>
				<div class="answer"><span class="answer-label">%s</span>%s</div>
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			esc_html__( 'Question', 'deux' ),
			esc_html( $atts['title'] ),
			esc_html__( 'Answer', 'deux' ),
			$content
		);
	}

	/**
	 * render to visual composer
	 * @return mixed
	 */
	public function mapping(){
		vc_map( array(
			'name'        => esc_html__( 'FAQ', 'deux' ),
			'description' => esc_html__( 'Question and answer toggle', 'deux' ),
			'base'        => 'deux_faq',
			'category'    => esc_html__( 'Deux', 'deux' ),
			'js_view'     => 'VcToggleView',
			'params'      => array(
				array(
					'heading'     => esc_html__( 'Question', 'deux' ),
					'description' => esc_html__( 'Enter title of toggle block.', 'deux' ),
					'type'        => 'textfield',
					'holder'      => 'h4',
					'class'       => 'vc_toggle_title wpb_element_title',
					'param_name'  => 'title',
					'value'       => esc_html__( 'Question content goes here', 'deux' ),
				),
				array(
					'heading'     => esc_html__( 'Answer', 'deux' ),
					'description' => esc_html__( 'Toggle block content.', 'deux' ),
					'type'        => 'textarea_html',
					'holder'      => 'div',
					'class'       => 'vc_toggle_content',
					'param_name'  => 'content',
					'value'       => esc_html__( 'Answer content goes here, click edit button to change this text.', 'deux' ),
				),
				array(
					'heading'     => esc_html__( 'Default state', 'deux' ),
					'description' => esc_html__( 'Select "Open" if you want toggle to be open by default.', 'deux' ),
					'type'        => 'dropdown',
					'param_name'  => 'open',
					'value'       => array(
						esc_html__( 'Closed', 'deux' ) => 'false',
						esc_html__( 'Open', 'deux' )   => 'true',
					),
				),
				vc_map_add_css_animation(),
				array(
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
					'param_name'  => 'el_class',
					'type'        => 'textfield',
				),
			),
		) );
	}
}


new Deux_Shortcode_Faq();