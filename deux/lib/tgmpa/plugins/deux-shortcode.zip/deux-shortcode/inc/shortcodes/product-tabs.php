<?php
class Deux_Shortcode_Product_Tabs extends WP_Shortcode_UI
{
	public $shortcode_name = 'product_tabs';

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * render the output of shotcode
	 * @param  array $atts
	 * @param  string $content
	 * @return mixed
	 */
	public function render( $atts, $content = null ){
		$atts = shortcode_atts( array(
			'per_page'      => 15,
			'columns'       => 4,
			'filter'        => 'category',
			'category'      => '',
			'load_more'     => false,
			'css_animation' => '',
			'el_class'      => '',
		), $atts );

		$css_class = array(
			'deux-product-grid',
			'deux-product-tabs',
			'deux-products',
			'deux-products-filterable',
			$this->get_css_animation( $atts['css_animation'] ),
			$atts['el_class'],
		);

		if ( $atts['filter'] ) {
			$css_class[] = 'filterable';
			$css_class[] = 'filter-by-' . $atts['filter'];
		}

		if ( $atts['load_more'] ) {
			$css_class[] = 'loadmore-enabled';
		}

		$filter = array();

		if ( 'category' == $atts['filter'] ) {
			if ( empty( $atts['category'] ) ) {
				$categories = get_terms( 'product_cat' );
			} else {
				$categories = get_terms( array(
					'taxonomy' => 'product_cat',
					'slug'     => explode( ',', trim( $atts['category'] ) ),
				) );
			}
			$product_count = wp_count_posts( 'product' );
			$filter = array( '<li data-filter=".product_cat-all" class="active">' . esc_html__( 'All', 'deux' ) . '<span class="cat-count">'.$product_count->publish.'</span></li>' );

			if ( $categories && ! is_wp_error( $categories ) ) {

				foreach ( $categories as $index => $category ) {
					$filter[] = sprintf(
						'<li data-filter=".product_cat-%s" class="%s">%s<span class="cat-count">%s</span></li>',
						esc_attr( $category->slug ),
						! $index ? 'active' : '',
						esc_html( $category->name ),
						esc_html( $category->count )
					);
				}
			}
		} elseif ( 'group' == $atts['filter'] ) {

			$filter = array( '<li data-filter=".all" class="active">' . esc_html__( 'All', 'deux' ) . '</li>' );
		 
			$filter[] = '<li data-filter=".best_sellers" class="">' . esc_html__( 'Best Sellers', 'deux' ) . '</li>';
			$filter[] = '<li data-filter=".new" class="">' . esc_html__( 'New Products', 'deux' ) . '</li>';
			$filter[] = '<li data-filter=".sale" class="">' . esc_html__( 'Sales Products', 'deux' ) . '</li>';
		}

		$loading = '
			<span class="loading-icon filter-loading-icon">
				<span class="bubble">
					<span class="dot"><span class="dot__color dot__color--1"></span></span>
				</span>
				<span class="bubble">
					<span class="dot"><span class="dot__color dot__color--2"></span></span>
				</span>
				<span class="bubble">
					<span class="dot"><span class="dot__color dot__color--3"></span></span>
				</span>
			</span>';

		return sprintf(
			'<div class="%s" data-columns="%s" data-per_page="%s" data-load_more="%s" data-nonce="%s">%s%s<div class="products-grid">%s</div></div>',
			esc_attr( implode( ' ', $css_class ) ),
			esc_attr( $atts['columns'] ),
			esc_attr( $atts['per_page'] ),
			esc_attr( $atts['load_more'] ),
			esc_attr( wp_create_nonce( 'deux_get_products' ) ),
			empty( $filter ) ? '' : '<div class="product-filter"><ul class="filter">' . implode( "\n\t", $filter ) . '</ul></div>',
			$loading,
			$this->product_loop( $atts )
		);
	}

	function all_product_count() {
		$product_count = wp_count_posts('product');
		return $product_count->publish;
	}

	/**
	 * render to visual composer
	 * @return mixed
	 */
	public function mapping(){
		vc_map( array(
			'name'        => esc_html__( 'Product Tabs', 'deux' ),
			'description' => esc_html__( 'Product grid grouped by tabs', 'deux' ),
			'base'        => 'deux_product_tabs',
			'category'    => esc_html__( 'Deux', 'deux' ),
			'params'      => array(
				array(
					'heading'     => esc_html__( 'Number Of Products', 'deux' ),
					'param_name'  => 'per_page',
					'type'        => 'textfield',
					'value'       => 15,
					'description' => esc_html__( 'Total number of products will be display in single tab', 'deux' ),
				),
				array(
					'heading'     => esc_html__( 'Columns', 'deux' ),
					'param_name'  => 'columns',
					'type'        => 'dropdown',
					'value'       => array(
						esc_html__( '4 Columns', 'deux' ) => 4,
						esc_html__( '5 Columns', 'deux' ) => 5,
						esc_html__( '6 Columns', 'deux' ) => 6,
					),
					'description' => esc_html__( 'Display products in how many columns', 'deux' ),
				),
				array(
					'heading'     => esc_html__( 'Tabs', 'deux' ),
					'description' => esc_html__( 'Select how to group products in tabs', 'deux' ),
					'param_name'  => 'filter',
					'type'        => 'dropdown',
					'value'       => array(
						esc_html__( 'Group by category', 'deux' ) => 'category',
						esc_html__( 'Group by feature', 'deux' )  => 'group',
					),
				),
				array(
					'heading'     => esc_html__( 'Categories', 'deux' ),
					'description' => esc_html__( 'Select what categories you want to use. Leave it empty to use all categories.', 'deux' ),
					'param_name'  => 'category',
					'type'        => 'autocomplete',
					'value'       => '',
					'settings'    => array(
						'multiple' => true,
						'sortable' => true,
						'values'   => $this->get_terms(),
					),
					'dependency'  => array(
						'element' => 'filter',
						'value'   => 'category',
					),
				),
				array(
					'heading'     => esc_html__( 'Load More Button', 'deux' ),
					'param_name'  => 'load_more',
					'type'        => 'checkbox',
					'value'       => array(
						esc_html__( 'Yes', 'deux' ) => 'yes',
					),
					'description' => esc_html__( 'Show load more button with ajax loading', 'deux' ),
				),
				vc_map_add_css_animation(),
				array(
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'param_name'  => 'el_class',
					'type'        => 'textfield',
					'value'       => '',
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
				),
			),
		) );
	}
}


new Deux_Shortcode_Product_Tabs();