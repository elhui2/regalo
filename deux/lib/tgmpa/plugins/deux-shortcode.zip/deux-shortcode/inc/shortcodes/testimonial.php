<?php
class Deux_Shortcode_Testimonial extends WP_Shortcode_UI
{
	public $shortcode_name = 'testimonial';

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * render the output of shotcode
	 * @param  array $atts
	 * @param  string $content
	 * @return mixed
	 */
	public function render( $atts, $content = null ){
		$atts = shortcode_atts( array(
			'image'         => '',
			'name'          => '',
			'company'       => '',
			'align'         => 'center',
			'css_animation' => '',
			'el_class'      => '',
		), $atts );

		$css_class = array(
			'deux-testimonial',
			'testimonial-align-' . $atts['align'],
			$this->get_css_animation( $atts['css_animation'] ),
			$atts['el_class'],
		);

		$image = '';
		if ( $atts['image'] ) {
			if ( function_exists( 'wpb_getImageBySize' ) ) {
				$image = wpb_getImageBySize( array(
					'attach_id'  => $atts['image'],
					'thumb_size' => '160x160',
				) );

				$image = $image['thumbnail'];
			} else {
				$image = wp_get_attachment_image_src( $atts['image'], 'large' );

				if ( $image ) {
					$image = sprintf( '<img alt="%s" src="%s" width="160" height="160">',
						esc_attr( $atts['image'] ),
						esc_url( $image[0] )
					);
				}
			}
		}

		$authors = array(
			'<span class="name">' . esc_html( $atts['name'] ) . '</span>',
			'<span class="company">' . esc_html( $atts['company'] ) . '</span>',
		);

		return sprintf(
			'<div class="%s">
				<div class="testimonial-entry">
					<div class="testimonial-content">%s</div>
					<div class="author-container">
						<div class="author-photo">%s</div>
						<div class="testimonial-author">%s</div>
					</div>
				</div>
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			$content,
			$image,
			implode( ', ', $authors )
		);
	}

	/**
	 * render to visual composer
	 * @return mixed
	 */
	public function mapping(){
		vc_map( array(
			'name'        => esc_html__( 'Testimonial', 'deux' ),
			'description' => esc_html__( 'Written review from a satisfied customer', 'deux' ),
			'base'        => 'deux_testimonial',
			'category'    => esc_html__( 'Deux', 'deux' ),
			'params'      => array(
				array(
					'heading'     => esc_html__( 'Photo', 'deux' ),
					'description' => esc_html__( 'Author photo or avatar. Recommend 160x160 in dimension.', 'deux' ),
					'type'        => 'attach_image',
					'param_name'  => 'image',
				),
				array(
					'heading'     => esc_html__( 'Name', 'deux' ),
					'description' => esc_html__( 'Enter full name of the author', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'name',
					'admin_label' => true,
				),
				array(
					'heading'     => esc_html__( 'Company', 'deux' ),
					'description' => esc_html__( 'Enter company name of author', 'deux' ),
					'param_name'  => 'company',
					'type'        => 'textfield',
					'admin_label' => true,
				),
				array(
					'heading'     => esc_html__( 'Alignment', 'deux' ),
					'description' => esc_html__( 'Select testimonial alignment', 'deux' ),
					'param_name'  => 'align',
					'type'        => 'dropdown',
					'value'       => array(
						esc_html__( 'Center', 'deux' ) => 'center',
						esc_html__( 'Left', 'deux' )   => 'left',
						esc_html__( 'Right', 'deux' )  => 'right',
					),
				),
				array(
					'heading'     => esc_html__( 'Content', 'deux' ),
					'description' => esc_html__( 'Testimonial content', 'deux' ),
					'type'        => 'textarea_html',
					'param_name'  => 'content',
					'holder'      => 'div',
				),
				vc_map_add_css_animation(),
				array(
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'el_class',
				),
			),
		) );
	}
}


new Deux_Shortcode_Testimonial();