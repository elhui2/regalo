<?php
class Deux_Shortcode_Pricing_Table extends WP_Shortcode_UI
{
	public $shortcode_name = 'pricing_table';

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * render the output of shotcode
	 * @param  array $atts
	 * @param  string $content
	 * @return mixed
	 */
	public function render( $atts, $content = null ){
		$atts = shortcode_atts( array(
			'name'          => '',
			'price'         => '',
			'currency'      => '$',
			'recurrence'    => esc_html__( 'Per Month', 'deux' ),
			'features'      => '',
			'button_text'   => esc_html__( 'Get Started', 'deux' ),
			'button_link'   => '',
			'color'         => '#16a085',
			'bgcolor'       => '#fff',
			'style'			=> 'style1',
			'featured'		=> '',
			'css_animation' => '',
			'el_class'      => '',
		), $atts );

		$css_class = array(
			'deux-pricing-table',
			'deux-price-' . $atts['style'],
			$this->get_css_animation( $atts['css_animation'] ),
			$atts['el_class'],
		);

		$features = vc_param_group_parse_atts( $atts['features'] );
		$list     = array();
		foreach ( $features as $feature ) {
			$list[] = sprintf( '<li><span class="feature-name">%s</span><span class="feature-value">%s</span></li>', $feature['name'], $feature['value'] );
		}

		$features = $list ? '<ul>' . implode( '', $list ) . '</ul>' : '';
		$link     = vc_build_link( $atts['button_link'] );
		$most_popular = '<span class="pricing-featured" style="background-color:'.esc_attr( $atts['color'] ).'; color: '.esc_attr( $atts['bgcolor'] ).';">' . esc_html( 'most popular', 'deux' ) . '</span>';

		if ($atts['style'] == 'style1') {
			$templates = sprintf(
				'<div class="%s">
					<div class="table-header" style="background-color: %s; color: %s;">
						<h3 class="plan-name">%s</h3>
						<div class="pricing"><span class="currency">%s</span>%s</div>
						<div class="recurrence">%s</div>
						<a href="%s" target="%s" rel="%s" title="%s" class="button" style="background-color: %s; color: %s;">%s</a>
					</div>
					<div class="table-content">%s</div>
				</div>',
				esc_attr( implode( ' ', $css_class ) ),
				esc_attr( $atts['featured'] ) ? esc_attr( $atts['color'] ) : esc_attr( $atts['bgcolor'] ),
				esc_attr( $atts['featured'] ) ? esc_attr( $atts['bgcolor'] ) : esc_attr( $atts['color'] ),
				esc_html( $atts['name'] ),
				esc_html( $atts['currency'] ),
				esc_html( $atts['price'] ),
				esc_html( $atts['recurrence'] ),
				esc_url( $link['url'] ),
				esc_attr( $link['target'] ),
				esc_attr( $link['rel'] ),
				esc_attr( $link['title'] ),
				esc_attr( $atts['featured'] ) ? esc_attr( $atts['bgcolor'] ) : esc_attr( $atts['color'] ),
				esc_attr( $atts['featured'] ) ? esc_attr( $atts['color'] ) : esc_attr( $atts['bgcolor'] ),
				esc_html( $atts['button_text'] ),
				$features
			);
		}
		else {

			$templates = sprintf(
				'<div class="%s">
					%s
					<div class="table-header" style="background-color: %s; color: %s;">
						<h3 class="plan-name">%s</h3>
						<div class="pricing">
							<span class="currency">%s</span>
							<span class="pricing-value">%s</span>
							<span class="recurrence">%s</span>
						</div>
					</div>
					<div class="table-content">%s</div>
					<div class="table-footer">
						<a href="%s" target="%s" rel="%s" title="%s" class="button" style="background-color: %s; color: %s;">%s</a>
					</div>
				</div>',
				esc_attr( implode( ' ', $css_class ) ),
				esc_attr( $atts['featured'] ) ?  $most_popular : '',
				esc_attr( $atts['bgcolor'] ),
				esc_attr( $atts['color'] ),
				esc_html( $atts['name'] ),
				esc_html( $atts['currency'] ),
				esc_html( $atts['price'] ),
				esc_html( $atts['recurrence'] ),
				$features,
				esc_url( $link['url'] ),
				esc_attr( $link['target'] ),
				esc_attr( $link['rel'] ),
				esc_attr( $link['title'] ),
				esc_attr( $atts['color'] ),
				esc_attr( $atts['bgcolor'] ),
				esc_html( $atts['button_text'] )
			);

		}

		return $templates;
	}

	/**
	 * render to visual composer
	 * @return mixed
	 */
	public function mapping(){
		vc_map( array(
			'name'        => esc_html__( 'Pricing Table', 'deux' ),
			'description' => esc_html__( 'Eye catching pricing table', 'deux' ),
			'base'        => 'deux_pricing_table',
			'category'    => esc_html__( 'Deux', 'deux' ),
			'params'      => array(
				array(
					'heading'     => esc_html__( 'Button Color Scheme', 'deux' ),
					'type'        => 'dropdown',
					'param_name'  => 'style',
					'value'       => array(
						esc_html__( 'Style 1', 'deux' )  => 'style1',
						esc_html__( 'Style 2', 'deux' ) => 'style2',
					),
				),
				array(
					'heading'     => esc_html__( 'Plan Name', 'deux' ),
					'admin_label' => true,
					'param_name'  => 'name',
					'type'        => 'textfield',
				),
				array(
					'heading'     => esc_html__( 'Price', 'deux' ),
					'description' => esc_html__( 'Plan pricing', 'deux' ),
					'param_name'  => 'price',
					'type'        => 'textfield',
				),
				array(
					'heading'     => esc_html__( 'Currency', 'deux' ),
					'description' => esc_html__( 'Price currency', 'deux' ),
					'param_name'  => 'currency',
					'type'        => 'textfield',
					'value'       => '$',
				),
				array(
					'heading'     => esc_html__( 'Recurrence', 'deux' ),
					'description' => esc_html__( 'Recurring payment unit', 'deux' ),
					'param_name'  => 'recurrence',
					'type'        => 'textfield',
					'value'       => esc_html__( 'Per Month', 'deux' ),
				),
				array(
					'heading'     => esc_html__( 'Features', 'deux' ),
					'description' => esc_html__( 'Feature list of this plan. Click to arrow button to edit.', 'deux' ),
					'param_name'  => 'features',
					'type'        => 'param_group',
					'params'      => array(
						array(
							'heading'    => esc_html__( 'Feature name', 'deux' ),
							'param_name' => 'name',
							'type'       => 'textfield',
						),
						array(
							'heading'    => esc_html__( 'Feature value', 'deux' ),
							'param_name' => 'value',
							'type'       => 'textfield',
						),
					),
				),
				array(
					'heading'    => esc_html__( 'Button Text', 'deux' ),
					'param_name' => 'button_text',
					'type'       => 'textfield',
					'value'      => esc_html__( 'Get Started', 'deux' ),
				),
				array(
					'heading'    => esc_html__( 'Button Link', 'deux' ),
					'param_name' => 'button_link',
					'type'       => 'vc_link',
					'value'      => esc_html__( 'Get Started', 'deux' ),
				),
				array(
					'heading'     => esc_html__( 'Table accent color', 'deux' ),
					'description' => esc_html__( 'Pick accent color scheme for this table.', 'deux' ),
					'param_name'  => 'color',
					'type'        => 'colorpicker',
					'value'       => '#16a085',
				),
				array(
					'heading'     => esc_html__( 'Table background color', 'deux' ),
					'description' => esc_html__( 'Pick background color scheme for this table.', 'deux' ),
					'param_name'  => 'bgcolor',
					'type'        => 'colorpicker',
					'value'       => '#fff',
				),
				array(
					'heading'     => esc_html__( 'Most popular', 'deux' ),
					'description' => esc_html__( 'Most popular pricing table', 'deux' ),
					'type'        => 'checkbox',
					'param_name'  => 'featured',
				),
				vc_map_add_css_animation(),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'param_name'  => 'el_class',
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
				),
			),
		) );
	}
}


new Deux_Shortcode_Pricing_Table();