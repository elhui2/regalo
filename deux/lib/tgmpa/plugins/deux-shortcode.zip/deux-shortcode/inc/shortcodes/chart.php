<?php
class Deux_Shortcode_Chart extends WP_Shortcode_UI
{
	public $shortcode_name = 'chart';

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * render the output of shotcode
	 * @param  array $atts
	 * @param  string $content
	 * @return mixed
	 */
	public function render( $atts, $content = null ){
		$atts = shortcode_atts( array(
			'value'         => 100,
			'size'          => 200,
			'thickness'     => 8,
			'label_source'  => 'auto',
			'label'         => '',
			'color'         => '#444',
			'css_animation' => '',
			'el_class'      => '',
		), $atts );

		$css_class = array(
			'deux-chart',
			'deux-chart-' . $atts['value'],
			$this->get_css_animation( $atts['css_animation'] ),
			$atts['el_class'],
		);

		$label = 'custom' == $atts['label_source'] ? $atts['label'] : '<span class="unit">%</span>' . esc_html( $atts['value'] );

		return sprintf(
			'<div class="%s" data-value="%s" data-size="%s" data-thickness="%s" data-fill="%s">
				<div class="text" style="color: %s">%s</div>
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			esc_attr( intval( $atts['value'] ) / 100 ),
			esc_attr( $atts['size'] ),
			esc_attr( $atts['thickness'] ),
			esc_attr( json_encode( array( 'color' => $atts['color'] ) ) ),
			esc_attr( $atts['color'] ),
			wp_kses_post( $label )
		);
	}

	/**
	 * render to visual composer
	 * @return mixed
	 */
	public function mapping(){
		vc_map( array(
			'name'        => esc_html__( 'Circle Chart', 'deux' ),
			'description' => esc_html__( 'Circle chart with animation', 'deux' ),
			'base'        => 'deux_chart',
			'category'    => esc_html__( 'Deux', 'deux' ),
			'params'      => array(
				array(
					'heading'     => esc_html__( 'Value', 'deux' ),
					'description' => esc_html__( 'Enter the chart value in percentage. Minimum 0 and maximum 100.', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'value',
					'value'       => 100,
					'admin_label' => true,
				),
				array(
					'heading'     => esc_html__( 'Circle Size', 'deux' ),
					'description' => esc_html__( 'Width of the circle', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'size',
					'value'       => 200,
				),
				array(
					'heading'     => esc_html__( 'Circle thickness', 'deux' ),
					'description' => esc_html__( 'Width of the arc', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'thickness',
					'value'       => 8,
				),
				array(
					'heading'     => esc_html__( 'Color', 'deux' ),
					'description' => esc_html__( 'Pick color for the circle', 'deux' ),
					'type'        => 'colorpicker',
					'param_name'  => 'color',
					'value'       => '#6dcff6',
				),
				array(
					'heading'     => esc_html__( 'Label Source', 'deux' ),
					'description' => esc_html__( 'Chart label source', 'deux' ),
					'param_name'  => 'label_source',
					'type'        => 'dropdown',
					'value'       => array(
						esc_html__( 'Auto', 'deux' )   => 'auto',
						esc_html__( 'Custom', 'deux' ) => 'custom',
					),
				),
				array(
					'heading'     => esc_html__( 'Custom label', 'deux' ),
					'description' => esc_html__( 'Text label for the chart', 'deux' ),
					'param_name'  => 'label',
					'type'        => 'textfield',
					'dependency'  => array(
						'element' => 'label_source',
						'value'   => 'custom',
					),
				),
				vc_map_add_css_animation(),
				array(
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'el_class',
				),
			),
		) );
	}
}


new Deux_Shortcode_Chart();