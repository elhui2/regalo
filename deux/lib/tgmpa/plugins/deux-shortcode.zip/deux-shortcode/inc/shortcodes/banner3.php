<?php
class Deux_Shortcode_Banner3 extends WP_Shortcode_UI
{
	public $shortcode_name = 'banner3';

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * render the output of shotcode
	 * @param  array $atts
	 * @param  string $content
	 * @return mixed
	 */
	public function render( $atts, $content = null ){
		$atts = shortcode_atts( array(
			'image'         => '',
			'image_size'    => '',
			'title'         => '',
			'vtitle'        => '',
			'sub'       	=> '',
			'text_align'    => 'center',
			'text_valign'   => 'left',
			'color'         => '',
			'link'          => '',
			'css_animation' => '',
			'el_class'      => '',
		), $atts );

		$css_class = array(
			'deux-banner3',
			'align-' . $atts['text_align'],
			'valign-' . $atts['text_valign'],
			$this->get_css_animation( $atts['css_animation'] ),
			$atts['el_class'],
		);
		$link      = vc_build_link( $atts['link'] );
		$image     = '';

		if ( $atts['image'] ) {
			$size = apply_filters( 'deux_banner_size', $atts['image_size'], $atts, 'deux_banner3' );

			if ( function_exists( 'wpb_getImageBySize' ) ) {
				$image = wpb_getImageBySize( array(
					'attach_id'  => $atts['image'],
					'thumb_size' => $size,
				) );

				$image = $image['thumbnail'];
			} else {
				$size_array = explode( 'x', $size );
				$size       = count( $size_array ) == 1 ? $size : $size_array;

				$image = wp_get_attachment_image_src( $atts['image'], $size );

				if ( $image ) {
					$image = sprintf( '<img alt="%s" src="%s">',
						esc_attr( $atts['text'] ),
						esc_url( $image[0] )
					);
				}
			}
		}

		return sprintf(
			'<div class="%s">
				<a href="%s" target="%s" rel="%s" title="%s">
					<figure>
						%s
					</figure>
					<span class="banner-vtitle" style="color: %s">%s</span>
					<div class="banner-content">
						<h3 class="banner-title">%s</h3>
						<span class="banner-subtitle">%s</span>
						<span class="banner-link">%s</span>
					</div>
				</a>
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			esc_url( $link['url'] ),
			esc_attr( $link['target'] ),
			esc_attr( $link['rel'] ),
			esc_attr( $link['title'] ),
			$image,
			esc_attr( $atts['color'] ),
			esc_attr( $atts['vtitle'] ),
			esc_attr( $atts['title'] ),
			esc_html( $atts['sub'] ),
			esc_attr( $link['title'] )
		);
	}

	/**
	 * render to visual composer
	 * @return mixed
	 */
	public function mapping(){
		vc_map( array(
			'name'        => esc_html__( 'Banner Image 3', 'deux' ),
			'description' => esc_html__( 'Simple banner with text at bottom', 'deux' ),
			'base'        => 'deux_banner3',
			'category'    => esc_html__( 'Deux', 'deux' ),
			'params'      => array(
				array(
					'heading'     => esc_html__( 'Image', 'deux' ),
					'description' => esc_html__( 'Banner Image', 'deux' ),
					'param_name'  => 'image',
					'type'        => 'attach_image',
				),
				array(
					'heading'     => esc_html__( 'Image size', 'deux' ),
					'description' => esc_html__( 'Enter image size. Example: "thumbnail", "medium", "large", "full" or other sizes defined by current theme. Alternatively enter image size in pixels: 200x100 (Width x Height). Leave empty to use "thumbnail" size.', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'image_size',
					'value'       => '',
				),
				array(
					'heading'     => esc_html__( 'Banner Title', 'deux' ),
					'description' => esc_html__( 'Enter banner text', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'title',
					'admin_label' => true,
				),
				array(
					'heading'     => esc_html__( 'Banner Subtitle', 'deux' ),
					'description' => esc_html__( 'Enter banner text', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'sub',
					'admin_label' => true,
				),
				array(
					'heading'     => esc_html__( 'Banner Vertical Title', 'deux' ),
					'description' => esc_html__( 'Enter banner text', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'vtitle',
					'admin_label' => true,
				),
				array(
					'heading'     => esc_html__( 'Banner Text Position', 'deux' ),
					'description' => esc_html__( 'Select text position', 'deux' ),
					'type'        => 'dropdown',
					'param_name'  => 'text_align',
					'value'       => array(
						esc_html__( 'Center', 'deux' ) => 'center',
						esc_html__( 'Left', 'deux' )   => 'left',
						esc_html__( 'Right', 'deux' )  => 'right',
					),
				),
				array(
					'heading'     => esc_html__( 'Banner Vetical Text Position', 'deux' ),
					'description' => esc_html__( 'Select text position', 'deux' ),
					'type'        => 'dropdown',
					'param_name'  => 'text_valign',
					'value'       => array(
						esc_html__( 'Left', 'deux' )   => 'left',
						esc_html__( 'Right', 'deux' )  => 'right',
					),
				),
				array(
					'heading'     => esc_html__( 'Text Color', 'deux' ),
					'description' => esc_html__( 'Pick color scheme for vertical title', 'deux' ),
					'param_name'  => 'color',
					'type'        => 'colorpicker',
					'value'       => '#333',
				),
				array(
					'heading'    => esc_html__( 'Link (URL)', 'deux' ),
					'type'       => 'vc_link',
					'param_name' => 'link',
				),
				vc_map_add_css_animation(),
				array(
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
					'param_name'  => 'el_class',
					'type'        => 'textfield',
					'value'       => '',
				),
			),
		) );
	}
}


new Deux_Shortcode_Banner3();