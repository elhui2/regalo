<?php
class Deux_Shortcode_Team_Member extends WP_Shortcode_UI
{
	public $shortcode_name = 'team_member';

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * render the output of shotcode
	 * @param  array $atts
	 * @param  string $content
	 * @return mixed
	 */
	public function render( $atts, $content = null ){
		$atts = shortcode_atts( array(
			'image'         => '',
			'image_size'    => 'full',
			'name'          => '',
			'job'           => '',
			'facebook'      => '',
			'twitter'       => '',
			'google'        => '',
			'pinterest'     => '',
			'linkedin'      => '',
			'youtube'       => '',
			'instagram'     => '',
			'css_animation' => '',
			'el_class'      => '',
		), $atts );

		$css_class = array(
			'deux-team-member',
			$this->get_css_animation( $atts['css_animation'] ),
			$atts['el_class'],
		);

		if ( $atts['image'] ) {
			if ( function_exists( 'wpb_getImageBySize' ) ) {
				$image = wpb_getImageBySize( array(
					'attach_id'  => $atts['image'],
					'thumb_size' => $atts['image_size'],
				) );

				$image = $image['thumbnail'];
			} else {
				$image = wp_get_attachment_image_src( $atts['image'], $atts['image_size'] );

				if ( $image ) {
					$image = sprintf( '<img src="%s" alt="%s" width="%s" height="%s">',
						esc_url( $image[0] ),
						esc_attr( $atts['name'] ),
						esc_attr( $image[1] ),
						esc_attr( $image[2] )
					);
				}
			}
		} else {
			$image = plugins_url( 'assets/images/man-placeholder.png', dirname( dirname( __FILE__ ) ) );
			$image = sprintf( '<img src="%s" alt="%s" width="360" height="430">',
				esc_url( $image ),
				esc_attr( $atts['name'] )
			);
		}

		$socials = array( 'facebook', 'twitter', 'google', 'pinterest', 'linkedin', 'youtube', 'instagram' );
		$links   = array();

		foreach ( $socials as $social ) {
			if ( empty( $atts[ $social ] ) ) {
				continue;
			}

			$icon = str_replace( array( 'google', 'pinterest', 'youtube' ), array(
				'google-plus',
				'pinterest-p',
				'youtube-play',
			), $social );

			$links[] = sprintf( '<a href="%s" target="_blank"><i class="fa fa-%s"></i></a>', esc_url( $atts[ $social ] ), esc_attr( $icon ) );
		}

		return sprintf(
			'<div class="%s">
				%s
				<div class="member-socials">%s</div>
				<div class="member-info">
					<h4 class="member-name">%s</h4>
					<span class="member-job">%s</span>
				</div>
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			$image,
			implode( '', $links ),
			esc_html( $atts['name'] ),
			esc_html( $atts['job'] )
		);
	}

	/**
	 * render to visual composer
	 * @return mixed
	 */
	public function mapping(){
		vc_map( array(
			'name'        => esc_html__( 'Team Member', 'deux' ),
			'description' => esc_html__( 'Single team member information', 'deux' ),
			'base'        => 'deux_team_member',
			'category'    => esc_html__( 'Deux', 'deux' ),
			'params'      => array(
				array(
					'heading'     => esc_html__( 'Image', 'deux' ),
					'description' => esc_html__( 'Member photo', 'deux' ),
					'param_name'  => 'image',
					'type'        => 'attach_image',
				),
				array(
					'heading'     => esc_html__( 'Image Size', 'deux' ),
					'description' => esc_html__( 'Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)). Leave empty to use "thumbnail" size.', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'image_size',
					'value'       => 'full',
				),
				array(
					'heading'     => esc_html__( 'Full Name', 'deux' ),
					'description' => esc_html__( 'Member name', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'name',
					'admin_label' => true,
				),
				array(
					'heading'     => esc_html__( 'Job', 'deux' ),
					'description' => esc_html__( 'The job/position name of member in your team', 'deux' ),
					'param_name'  => 'job',
					'type'        => 'textfield',
					'admin_label' => true,
				),
				array(
					'heading'    => esc_html__( 'Facebook', 'deux' ),
					'type'       => 'textfield',
					'param_name' => 'facebook',
				),
				array(
					'heading'    => esc_html__( 'Twitter', 'deux' ),
					'type'       => 'textfield',
					'param_name' => 'twitter',
				),
				array(
					'heading'    => esc_html__( 'Google Plus', 'deux' ),
					'type'       => 'textfield',
					'param_name' => 'google',
				),
				array(
					'heading'    => esc_html__( 'Pinterest', 'deux' ),
					'type'       => 'textfield',
					'param_name' => 'pinterest',
				),
				array(
					'heading'    => esc_html__( 'Linkedin', 'deux' ),
					'type'       => 'textfield',
					'param_name' => 'linkedin',
				),
				array(
					'heading'    => esc_html__( 'Youtube', 'deux' ),
					'type'       => 'textfield',
					'param_name' => 'youtube',
				),
				array(
					'heading'    => esc_html__( 'Instagram', 'deux' ),
					'type'       => 'textfield',
					'param_name' => 'instagram',
				),
				vc_map_add_css_animation(),
				array(
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
					'param_name'  => 'el_class',
					'type'        => 'textfield',
				),
			),
		) );
	}
}


new Deux_Shortcode_Team_Member();