<?php
class Deux_Shortcode_Post_Grid extends WP_Shortcode_UI
{
	public $shortcode_name = 'post_grid';

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * render the output of shotcode
	 * @param  array $atts
	 * @param  string $content
	 * @return mixed
	 */
	public function render( $atts, $content = null ){
		$atts = shortcode_atts( array(
			'per_page'      => 3,
			'columns'       => 3,
			'category'      => '',
			'css_animation' => '',
			'el_class'      => '',
		), $atts );

		$css_class = array(
			'deux-post-grid',
			'post-grid',
			'columns-' . $atts['columns'],
			$this->get_css_animation( $atts['css_animation'] ),
			$atts['el_class'],
		);

		$output = array();

		$args = array(
			'post_type'              => 'post',
			'posts_per_page'         => $atts['per_page'],
			'ignore_sticky_posts'    => 1,
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
		);

		if ( $atts['category'] ) {
			$args['category_name'] = trim( $atts['category'] );
		}

		$posts = new WP_Query( $args );

		if ( ! $posts->have_posts() ) {
			return '';
		}

		$column_class = 'col-sm-6 col-md-' . ( 12 / absint( $atts['columns'] ) );

		while ( $posts->have_posts() ) : $posts->the_post();
			$post_class = get_post_class( $column_class );
			$thumbnail  = $meta = '';

			if ( has_post_thumbnail() ) :
				$icon = '';

				if ( 'gallery' == get_post_format() ) {
					$icon = '<span class="format-icon"><i class="fa fa-clone"></i></span>';
				} elseif ( 'video' == get_post_format() ) {
					$icon = '<span class="format-icon"><i class="fa fa-play"></i></span>';
				}  elseif ( 'audio' == get_post_format() ) {
					$icon = '<span class="format-icon"><i class="fa fa-music"></i></span>';
				}

				$thumbnail = sprintf(
					'<a href="%s" class="post-thumbnail">%s%s</a>',
					esc_url( get_permalink() ),
					get_the_post_thumbnail( get_the_ID(), 'deux-blog-grid' ),
					$icon
				);
			endif;

				$posted_on = sprintf(
					'<time class="entry-date published updated" datetime="%1$s"><span>%2$s</span><span>%3$s</span></time>',
					esc_attr( get_the_date( 'c' ) ),
					esc_html( get_the_date( 'd' ) ),
					esc_html( get_the_date( 'M y' ) )
				);

				$categories_list = has_post_thumbnail() ? get_the_category_list( ' ' ) : '';

				$meta = '<span class="posted-on">' . $posted_on . '</span>'; // WPCS: XSS OK.

			$output[] = sprintf(
				'<div class="%s">
					<div class="entry-meta-category"><span class="cat-links">%s</span></div>
					%s
					<div class="post-summary">
						<div class="entry-meta">%s</div>
						<h3 class="entry-title"><a href="%s" rel="bookmark">%s</a></h3>
					</div>
				</div>',
				esc_attr( implode( ' ', $post_class ) ),
				$categories_list,
				$thumbnail,
				$meta,
				esc_url( get_permalink() ),
				get_the_title()
			);
		endwhile;

		wp_reset_postdata();

		return sprintf(
			'<div class="deux-post-grid post-grid %s">
				<div class="row">%s</div>
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}

	/**
	 * render to visual composer
	 * @return mixed
	 */
	public function mapping(){
		vc_map( array(
			'name'        => esc_html__( 'Post Grid', 'deux' ),
			'description' => esc_html__( 'Display posts in grid', 'deux' ),
			'base'        => 'deux_post_grid',
			'category'    => esc_html__( 'Deux', 'deux' ),
			'params'      => array(
				array(
					'description' => esc_html__( 'Number of posts you want to show', 'deux' ),
					'heading'     => esc_html__( 'Number of posts', 'deux' ),
					'param_name'  => 'per_page',
					'type'        => 'textfield',
					'value'       => 3,
				),
				array(
					'heading'     => esc_html__( 'Columns', 'deux' ),
					'description' => esc_html__( 'Display posts in how many columns', 'deux' ),
					'param_name'  => 'columns',
					'type'        => 'dropdown',
					'value'       => array(
						esc_html__( '3 Columns', 'deux' ) => 3,
						esc_html__( '4 Columns', 'deux' ) => 4,
					),
				),
				array(
					'heading'     => esc_html__( 'Category', 'deux' ),
					'description' => esc_html__( 'Enter categories name', 'deux' ),
					'param_name'  => 'category',
					'type'        => 'autocomplete',
					'settings'    => array(
						'multiple' => true,
						'sortable' => true,
						'values'   => $this->get_terms( 'category' ),
					),
				),
				vc_map_add_css_animation(),
				array(
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
					'param_name'  => 'el_class',
					'type'        => 'textfield',
					'value'       => '',
				),
			),
		) );
	}
}


new Deux_Shortcode_Post_Grid();