<?php
class Deux_Shortcode_Message_Box extends WP_Shortcode_UI
{
	public $shortcode_name = 'message_box';

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * render the output of shotcode
	 * @param  array $atts
	 * @param  string $content
	 * @return mixed
	 */
	public function render( $atts, $content = null ){
		$atts = shortcode_atts( array(
			'type'          => 'success',
			'closeable'     => true,
			'css_animation' => '',
			'el_class'      => '',
		), $atts );

		$css_class = array(
			'deux-message-box',
			$atts['type'],
			$this->get_css_animation( $atts['css_animation'] ),
			$atts['el_class'],
		);

		if ( $atts['closeable'] ) {
			$css_class[] = 'closeable';
		}
		$icon = str_replace( array( 'success', 'danger' ), array( 'check', 'exclamation' ), $atts['type'] );


		return sprintf(
			'<div class="%s">
				<span class="message-icon"><i class="fa fa-%s"></i></span>
				<div class="box-content">%s</div>
				%s
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			esc_attr( $icon ),
			$content,
			$atts['closeable'] ? '<a class="close" href="#"><i class="fa fa-close"></i></a>' : ''
		);
	}

	/**
	 * render to visual composer
	 * @return mixed
	 */
	public function mapping(){
		vc_map( array(
			'name'        => esc_html__( 'Message Box', 'deux' ),
			'description' => esc_html__( 'Notification box with close button', 'deux' ),
			'base'        => 'deux_message_box',
			'category'    => esc_html__( 'Deux', 'deux' ),
			'params'      => array(
				array(
					'heading'          => esc_html__( 'Type', 'deux' ),
					'description'      => esc_html__( 'Select message box type', 'deux' ),
					'edit_field_class' => 'vc_col-xs-12 vc_message-type',
					'type'             => 'dropdown',
					'param_name'       => 'type',
					'default'          => 'success',
					'admin_label'      => true,
					'value'            => array(
						esc_html__( 'Success', 'deux' )       => 'success',
						esc_html__( 'Informational', 'deux' ) => 'info',
						esc_html__( 'Error', 'deux' )         => 'danger',
						esc_html__( 'Warning', 'deux' )       => 'warning',
					),
				),
				array(
					'heading'    => esc_html__( 'Message Text', 'deux' ),
					'type'       => 'textarea_html',
					'param_name' => 'content',
					'holder'     => 'div',
				),
				array(
					'heading'     => esc_html__( 'Closeable', 'deux' ),
					'description' => esc_html__( 'Display close button for this box', 'deux' ),
					'type'        => 'checkbox',
					'param_name'  => 'closeable',
					'value'       => array(
						esc_html__( 'Yes', 'deux' ) => true,
					),
				),
				vc_map_add_css_animation(),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'param_name'  => 'el_class',
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
				),
			),
		) );
	}
}


new Deux_Shortcode_Message_Box();