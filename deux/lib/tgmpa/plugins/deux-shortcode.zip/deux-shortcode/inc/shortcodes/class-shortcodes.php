<?php

class Deux_Shortcodes {
	public static $current_banner = 1;

	/**
	 * Init shortcodes
	 */
	public static function init() {
		$shortcodes = array(
			'container_slider',
			'banner_grid_4',
			'banner_grid_5',
			'banner_grid_6',
		);

		foreach ( $shortcodes as $shortcode ) {
			add_shortcode( 'deux_' . $shortcode, array( __CLASS__, $shortcode ) );
		}
	}

	/**
	 * Container Slider
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	public static function container_slider( $atts, $content ) {
		$atts = shortcode_atts( array(
			'el_class' 		=> '',
			'columns'       => 1,
			'autoplay'      => 5000,
			'loop'          => false,
		), $atts, 'deux_' . __FUNCTION__ );

		$content = do_shortcode( $content );
		return '<div class="deux-carousel ' . esc_attr( $atts['el_class'] ) . '" 
						data-columns="' . esc_attr( $atts['columns'] ) . '" 
						data-autoplay="' . esc_attr( $atts['autoplay'] ) . '" 
						data-loop="' . esc_attr( $atts['loop'] ) . '">
							<div class="products">' . $content . '</div></div>';
	}
 
	/**
	 * Banner grid 4
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	public static function banner_grid_4( $atts, $content ) {
		$atts = shortcode_atts( array(
			'el_class' => '',
			'gap'      => 'true',
		), $atts, 'deux_' . __FUNCTION__ );
		$css_class = array(
			'deux-banner-grid-4 ',
			'gap-' . $atts['gap'],
			$atts['el_class'],
		);
		// Reset banner counter
		self::$current_banner = 1;

		add_filter( 'deux_banner_size', array( __CLASS__, 'banner_grid_4_banner_size' ) );
		$content = do_shortcode( $content );
		remove_filter( 'deux_banner_size', array( __CLASS__, 'banner_grid_4_banner_size' ) );

		return '<div class="' . esc_attr( implode( ' ', $css_class ) ) . '">' . $content . '</div>';
	}

	/**
	 * Banner grid 5
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	public static function banner_grid_5( $atts, $content ) {
		$atts = shortcode_atts( array(
			'el_class' => '',
			'gap'      => 'true',
		), $atts, 'deux_' . __FUNCTION__ );
		$css_class = array(
			'deux-banner-grid-5 ',
			'gap-' . $atts['gap'],
			$atts['el_class'],
		);
		// Reset banner counter
		self::$current_banner = 1;

		add_filter( 'deux_banner_size', array( __CLASS__, 'banner_grid_5_banner_size' ) );
		$content = do_shortcode( $content );
		remove_filter( 'deux_banner_size', array( __CLASS__, 'banner_grid_5_banner_size' ) );

		return '<div class="' . esc_attr( implode( ' ', $css_class ) ) . '">' . $content . '</div>';
	}

	/**
	 * Banner grid 6
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	public static function banner_grid_6( $atts, $content ) {
		$atts = shortcode_atts( array(
			'reverse'  => 'no',
			'gap'      => 'true',
			'el_class' => '',
		), $atts, 'deux_' . __FUNCTION__ );

		$css_class = array(
			'deux-banner-grid-6 ',
			'gap-' . $atts['gap'],
			$atts['el_class'],
		);

		if ( 'yes' == $atts['reverse'] ) {
			$css_class[] = 'reverse-order';
		}

		// Reset banner counter
		self::$current_banner = 1;

		add_filter( 'deux_banner_size', array( __CLASS__, 'banner_grid_6_banner_size' ) );
		$content = do_shortcode( $content );
		remove_filter( 'deux_banner_size', array( __CLASS__, 'banner_grid_6_banner_size' ) );

		return '<div class="' . esc_attr( implode( ' ', $css_class ) ) . '">' . $content . '</div>';
	}

	/**
	 * Change banner size while it is inside a banner grid 4
	 *
	 * @param string $size
	 *
	 * @return string
	 */
	public static function banner_grid_4_banner_size( $size ) {
		switch ( self::$current_banner % 8 ) {
			case 1:
			case 4:
			case 5:
			case 0:
				$size = '664x780';
				break;

			case 2:
			case 3:
			case 6:
			case 7:
				$size = '900x700';
				break;
		}

		self::$current_banner ++;

		return $size;
	}

	/**
	 * Change banner size while it is inside a banner grid 5
	 *
	 * @param string $size
	 *
	 * @return string
	 */
	public static function banner_grid_5_banner_size( $size ) {
		switch ( self::$current_banner % 5 ) {
			case 3:
			case 4:
				$size = '520x400';
				break;

			case 1:
				$size = '750x920';
				break;

			case 2:
			case 0:
				$size = '520x500';
				break;
		}

		self::$current_banner ++;

		return $size;
	}

	/**
	 * Change banner size while it is inside a banner grid 6
	 *
	 * @param string $size
	 *
	 * @return string
	 */
	public static function banner_grid_6_banner_size( $size ) {
		switch ( self::$current_banner % 6 ) {
			case 1:
				$size = '640x800';
				break;

			case 2:
			case 3:
				$size = '640x395';
				break;

			case 4:
			case 5:
			case 0:
				$size = '426x398';
				break;
		}

		self::$current_banner ++;

		return $size;
	}
}
