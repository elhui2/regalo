<?php
class Deux_Shortcode_Map extends WP_Shortcode_UI
{
	public $shortcode_name = 'map';

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * render the output of shotcode
	 * @param  array $atts
	 * @param  string $content
	 * @return mixed
	 */
	public function render( $atts, $content = null ){
		$atts = shortcode_atts( array(
			'api_key'       => '',
			'marker'        => '',
			'addresses'     => '',
			'height'        => '500px',
			'zoom'          => 15,
			'color'         => '',
			'store'         => '',
			'css_animation' => '',
			'el_class'      => '',
		), $atts );

		if ( empty( $atts['api_key'] ) ) {
			return esc_html__( 'Google map requires API Key in order to work.', 'deux' );
		}

		if ( empty( $atts['addresses'] ) ) {
			return '';
		}

		
		$addresses = (array) json_decode( urldecode( $atts['addresses'] ), true );
		
		$output_lat = array();
		$output_long = array();
		$output_address = array();
		$output_content = array();
		$output_store_content = array();
		$i      = 0;
		foreach ( $addresses as $address ) {

			$coordinates = $this->get_coordinates( $address['address'], $atts['api_key'] );

			$output_lat[] = $coordinates['lat'];
			$output_long[] = $coordinates['lng'];
			$output_address[] = $address['address'];
			$output_content[] = $address['address_content'];

			if ( !empty( $atts[ 'store' ] ) ) {
				$output_store_content[] = '<div class="map-item" data-number="'.$i.'">'. $address['address_content'] . '<span class="map-address" >' . $coordinates['address'] . '</span></div>';
				$i++;
			}
			 
		}

		$output_store = '';

		if ( !empty( $atts[ 'store' ] ) ) {
			$output_store = sprintf('<div class="map-location">
										<div class="map-label">
											%s
										</div>
									</div>',
								implode( ' ',  $output_store_content )
							);
		}

		if ( ! empty( $coordinates['error'] ) ) {
			return $coordinates['error'];
		}
		$css_class = array(
			'deux-map-container',
			$this->get_css_animation( $atts['css_animation'] ),
			$atts['el_class'],
			'store-' . $atts['store'],
		);

		$style = array();
		if ( $atts['height'] ) {
			$style[] = 'height: ' . intval( $atts['height'] ) . 'px';
		}

		$marker = '';

		if ( $atts['marker'] ) {
			if ( filter_var( $atts['marker'], FILTER_VALIDATE_URL ) ) {
				$marker = $atts['marker'];
			} else {
				$attachment_image = wp_get_attachment_image_src( intval( $atts['marker'] ), 'full' );
				$marker           = $attachment_image ? $attachment_image[0] : '';
			}
		}

		wp_enqueue_script( 'google-maps', 'https://maps.googleapis.com/maps/api/js?key=' . $atts['api_key'] );

		return sprintf(
			'<div class="%s"> 
				<div class="deux-map" style="%s" data-zoom="%s" data-lat="%s " data-lng="%s " data-address="%s/" data-color="%s" data-marker="%s">%s//</div>
				%s
			</div><div class="clearfix"></div>',
			implode( ' ', $css_class ),
			implode( ';', $style ),
			absint( $atts['zoom'] ),
			implode( ' ',   $output_lat ),
			implode( ' ',  $output_long ),
			implode( '/',  $output_address ),
			esc_attr( $atts['color'] ),
			esc_attr( $marker ),
			implode( '//',  $output_content ),
			$output_store
		);
	}

	/**
	 * render to visual composer
	 * @return mixed
	 */
	public function mapping(){
		vc_map( array(
			'name'        => esc_html__( 'Maps', 'deux' ),
			'description' => esc_html__( 'Google maps in style', 'deux' ),
			'base'        => 'deux_map',
			'category'    => esc_html__( 'Deux', 'deux' ),
			'params'      => array(

				array(
					'heading'     => esc_html__( 'API Key', 'deux' ),
					'description' => sprintf( __( 'Please go to <a href="%s">Google Maps APIs</a> to get a key', 'deux' ), esc_url( 'https://developers.google.com/maps/documentation/javascript/get-api-key#get-an-api-key' ) ),
					'type'        => 'textfield',
					'param_name'  => 'api_key',
				),
				array(
					'heading'     => esc_html__( 'Store Location', 'deux' ),
					'description' => esc_html__( 'Display Store Location', 'deux' ),
					'type'        => 'checkbox',
					'param_name'  => 'store',
					'value'       => array(
						esc_html__( 'Yes', 'deux' ) => 'true',
					),
				),
				array(
						'heading'    => esc_html__( 'Addresses', 'unero' ),
						'type'       => 'param_group',
						'value'      => '',
						'param_name' => 'addresses',
						'params'     => array(
							array(
								'heading'     => esc_html__( 'Address', 'deux' ),
								'description' => esc_html__( 'Enter address for map marker', 'deux' ),
								'type'        => 'textfield',
								'param_name'  => 'address',
								'admin_label' => true,
							),
							array(
								'heading'     => esc_html__( 'Content', 'deux' ),
								'description' => esc_html__( 'Enter content of info window (you can enter html tag).', 'deux' ),
								'type'        => 'textarea',
								'param_name'  => 'address_content',
								'holder'      => 'div',
							),
						)
				),
				
				array(
					'heading'     => esc_html__( 'Marker', 'deux' ),
					'description' => esc_html__( 'Upload custom marker icon or leave this to use default marker.', 'deux' ),
					'param_name'  => 'marker',
					'type'        => 'attach_image',
				),
				array(
					'heading'     => esc_html__( 'Height', 'deux' ),
					'description' => esc_html__( 'Map height in pixel.', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'height',
					'value'       => '500px',
				),
				array(
					'heading'     => esc_html__( 'Zoom', 'deux' ),
					'description' => esc_html__( 'Enter zoom level. The value is between 1 and 20.', 'deux' ),
					'param_name'  => 'zoom',
					'type'        => 'textfield',
					'value'       => '15',
				),
				array(
					'heading'          => esc_html__( 'Color', 'deux' ),
					'description'      => esc_html__( 'Select map color style', 'deux' ),
					'edit_field_class' => 'vc_col-xs-12 vc_btn3-colored-dropdown vc_colored-dropdown',
					'param_name'       => 'color',
					'type'             => 'dropdown',
					'value'            => array(
						esc_html__( 'Default', 'deux' )       => '',
						esc_html__( 'Grey', 'deux' )          => 'grey',
						esc_html__( 'Classic Black', 'deux' ) => 'inverse',
						esc_html__( 'Blue', 'deux' )    => 'blue',
					),
				),
				
				vc_map_add_css_animation(),
				array(
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'el_class',
				),
			),
		) );
	}
}


new Deux_Shortcode_Map();