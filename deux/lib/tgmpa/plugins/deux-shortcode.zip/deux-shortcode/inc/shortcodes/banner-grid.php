<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

if ( class_exists( 'WPBakeryShortCode' ) ) :

class WPBakeryShortCode_Deux_Banner_Grid_4 extends WPBakeryShortCodesContainer {
}

class WPBakeryShortCode_Deux_Banner_Grid_5 extends WPBakeryShortCodesContainer {
}

class WPBakeryShortCode_Deux_Banner_Grid_6 extends WPBakeryShortCodesContainer {
}

class WPBakeryShortCode_Deux_Container_Slider extends WPBakeryShortCodesContainer {
}

endif;