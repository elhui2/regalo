<?php
class Deux_Shortcode_Contact_box extends WP_Shortcode_UI
{
	public $shortcode_name = 'contact_box';

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * render the output of shotcode
	 * @param  array $atts
	 * @param  string $content
	 * @return mixed
	 */
	public function render( $atts, $content = null ){
		$atts = shortcode_atts( array(
			'address'       => '',
			'phone'         => '',
			'fax'           => '',
			'email'         => '',
			'website'       => '',
			'css_animation' => '',
			'el_class'      => '',
		), $atts );

		$css_class = array(
			'deux-contact-box',
			$this->get_css_animation( $atts['css_animation'] ),
			$atts['el_class'],
		);
		$contact   = array();

		foreach ( array( 'address', 'phone', 'fax', 'email', 'website' ) as $info ) {
			if ( empty( $atts[ $info ] ) ) {
				continue;
			}

			$icon   = $name = '';
			$detail = esc_html( $atts[ $info ] );
			switch ( $info ) {
				case 'address':
					$name = esc_html__( 'Address', 'deux' );
					$icon = '<svg width="20" height="20" class="info-icon"><use xlink:href="#home"></use></svg>';
					break;

				case 'phone':
					$name   = esc_html__( 'Phone', 'deux' );
					$icon   = '<svg width="20" height="20" class="info-icon"><use xlink:href="#phone"></use></svg>';
					$detail = '<a href="tel:' . esc_attr( $atts[ $info ] ) . '">' . $detail . '</a>';
					break;

				case 'fax':
					$name = esc_html__( 'Fax', 'deux' );
					$icon = '<i class="info-icon fa fa-fax"></i>';
					break;

				case 'email':
					$name   = esc_html__( 'Email', 'deux' );
					$icon   = '<svg width="20" height="20" class="info-icon"><use xlink:href="#mail"></use></svg>';
					$detail = '<a href="mailto:' . esc_attr( $atts[ $info ] ) . '">' . $detail . '</a>';
					break;

				case 'website':
					$name   = esc_html__( 'Website', 'deux' );
					$icon   = '<i class="info-icon fa fa-globe"></i>';
					$detail = '<a href="' . esc_url( $atts[ $info ] ) . '" target="_blank" rel="nofollow">' . $detail . '</a>';
					break;
			}

			$contact[] = sprintf(
				'<div class="contact-info">
					%s
					<span class="info-name">%s</span>
					<span class="info-value">%s</span>
				</div>',
				$icon,
				$name,
				$detail
			);
		}

		return sprintf( '<div class="%s">%s</div>', esc_attr( implode( ' ', $css_class ) ), implode( ' ', $contact ) );
	}

	/**
	 * render to visual composer
	 * @return mixed
	 */
	public function mapping(){
		vc_map( array(
			'name'        => esc_html__( 'Contact Box', 'deux' ),
			'description' => esc_html__( 'Contact information', 'deux' ),
			'base'        => 'deux_contact_box',
			'category'    => esc_html__( 'Deux', 'deux' ),
			'params'      => array(
				array(
					'heading'     => esc_html__( 'Address', 'deux' ),
					'description' => esc_html__( 'The office address', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'address',
					'holder'      => 'p',
				),
				array(
					'heading'     => esc_html__( 'Phone', 'deux' ),
					'description' => esc_html__( 'The phone number', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'phone',
					'holder'      => 'p',
				),
				array(
					'heading'     => esc_html__( 'Fax', 'deux' ),
					'description' => esc_html__( 'The fax number', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'fax',
					'holder'      => 'p',
				),
				array(
					'heading'     => esc_html__( 'Email', 'deux' ),
					'description' => esc_html__( 'The email adress', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'email',
					'holder'      => 'p',
				),
				array(
					'heading'     => esc_html__( 'Website', 'deux' ),
					'description' => esc_html__( 'The phone number', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'website',
					'holder'      => 'p',
				),
				vc_map_add_css_animation(),
				array(
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'el_class',
				),
			),
		) );
	}
}


new Deux_Shortcode_Contact_box();