<?php
class Deux_Shortcode_Post_Image extends WP_Shortcode_UI
{
	public $shortcode_name = 'post_image';

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * render the output of shotcode
	 * @param  array $atts
	 * @param  string $content
	 * @return mixed
	 */
	public function render( $atts, $content = null ){
		$atts = shortcode_atts( array(
			'per_page'      => 4,
			'category'      => '',
			'css_animation' => '',
			'el_class'      => '',
		), $atts );

		$css_class = array(
			'deux-post-image',
			$this->get_css_animation( $atts['css_animation'] ),
			$atts['el_class'],
		);

		$output = array();

		$args = array(
			'post_type'              => 'post',
			'posts_per_page'         => $atts['per_page'],
			'ignore_sticky_posts'    => 1,
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
		);

		if ( $atts['category'] ) {
			$args['category_name'] = trim( $atts['category'] );
		}

		$posts = new WP_Query( $args );

		if ( ! $posts->have_posts() ) {
			return '';
		}


		while ( $posts->have_posts() ) : $posts->the_post();
			$post_class = get_post_class();
			$thumbnail  = $meta = '';

			if ( has_post_thumbnail() ) :
				$thumbnail = sprintf(
					'%s',
					get_the_post_thumbnail_url( get_the_ID(), 'large' )
				);
			endif;

			$posted_on = sprintf(
				'<time class="entry-date published updated" datetime="%1$s"><span>%2$s</span></time>',
				esc_attr( get_the_date( 'c' ) ),
				esc_html( get_the_date( 'd F, Y' ) )
			);

			$categories_list = get_the_category_list( ' ' );

			$meta = '<span class="posted-on">' . $posted_on . '</span>'; // WPCS: XSS OK.

			$output[] = sprintf(
				'<div class="%s">
					<div class="post-container">
						<div class="entry-image" style="background-image:url(%s)"></div>
						<div class="post-summary">
							<h3 class="entry-title"><a href="%s" rel="bookmark">%s</a></h3>
							<div class="entry-meta">%s <span class="cat-links">%s</span></div>
						</div>
					</div>
				</div>',
				esc_attr( implode( ' ', $post_class ) ),
				$thumbnail,
				esc_url( get_permalink() ),
				get_the_title(),
				$meta,
				$categories_list

			);
		endwhile;

		wp_reset_postdata();

		return sprintf(
			'<div class="deux-post-image %s">
				%s
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}

	/**
	 * render to visual composer
	 * @return mixed
	 */
	public function mapping(){
		vc_map( array(
			'name'        => esc_html__( 'Post Image', 'deux' ),
			'description' => esc_html__( 'Display posts in style', 'deux' ),
			'base'        => 'deux_post_image',
			'category'    => esc_html__( 'Deux', 'deux' ),
			'params'      => array(
				array(
					'heading'     => esc_html__( 'Category', 'deux' ),
					'description' => esc_html__( 'Enter categories name', 'deux' ),
					'param_name'  => 'category',
					'type'        => 'autocomplete',
					'settings'    => array(
						'multiple' => true,
						'sortable' => true,
						'values'   => $this->get_terms( 'category' ),
					),
				),
				vc_map_add_css_animation(),
				array(
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
					'param_name'  => 'el_class',
					'type'        => 'textfield',
					'value'       => '',
				),
			),
		) );
	}
}


new Deux_Shortcode_Post_Image();