<?php
class Deux_Shortcode_Credit_Card extends WP_Shortcode_UI
{
	public $shortcode_name = 'credit_card';

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * render the output of shotcode
	 * @param  array $atts
	 * @param  string $content
	 * @return mixed
	 */
	public function render( $atts, $content = null ){
		$atts = shortcode_atts( array(
			'paypal' 		=> '',
			'stripe' 		=> '',
			'mastercard' 	=> '',
			'visa'         	=> '',
			'discover'    	=> '',
			'amex'   		=> '',
			'jcb' 			=> '',
			'color' 		=> '',
		), $atts );

		$css_class = array(
			'deux-credit-card',
		);

		$cards = array( 'paypal', 'stripe', 'mastercard', 'visa', 'discover', 'amex', 'jcb' );
		$cards_output   = array();
		foreach ( $cards as $card ) {
			if ( empty( $atts[ $card ] ) ) {
				continue;
			}
			$cards_output[] = sprintf( '<li><i class="fa fa-cc-%s"></i></li>',  $card );

		}
	 

		return sprintf(
			'<ul class="%s" style="color:%s">
				%s 
			</ul>',
			esc_attr( implode( ' ', $css_class ) ),
			esc_html( $atts['color'] ),
			implode( '', $cards_output )
		);
	}

	/**
	 * render to visual composer
	 * @return mixed
	 */
	public function mapping(){
		vc_map( array(
			'name'        => esc_html__( 'Credit Card', 'deux' ),
			'description' => esc_html__( 'Simple icon credit card', 'deux' ),
			'base'        => 'deux_credit_card',
			'category'    => esc_html__( 'Deux', 'deux' ),
			'params'      => array(
				array(
					'heading'     => esc_html__( 'PayPal', 'deux' ),
					'description' => esc_html__( 'Display Paypal Icon', 'deux' ),
					'type'        => 'checkbox',
					'param_name'  => 'paypal',
					'value'       => array(
						esc_html__( 'Yes', 'deux' ) => 'true',
					),
				),
				array(
					'heading'     => esc_html__( 'Stripe', 'deux' ),
					'description' => esc_html__( 'Display Stripe Icon', 'deux' ),
					'type'        => 'checkbox',
					'param_name'  => 'stripe',
					'value'       => array(
						esc_html__( 'Yes', 'deux' ) => 'true',
					),
				),
				array(
					'heading'     => esc_html__( 'Mastercard', 'deux' ),
					'description' => esc_html__( 'Display Mastercard Icon', 'deux' ),
					'type'        => 'checkbox',
					'param_name'  => 'mastercard',
					'value'       => array(
						esc_html__( 'Yes', 'deux' ) => 'true',
					),
				),
			 	array(
					'heading'     => esc_html__( 'Visa', 'deux' ),
					'description' => esc_html__( 'Display Visa Icon', 'deux' ),
					'type'        => 'checkbox',
					'param_name'  => 'visa',
					'value'       => array(
						esc_html__( 'Yes', 'deux' ) => 'true',
					),
				),
				array(
					'heading'     => esc_html__( 'Discover', 'deux' ),
					'description' => esc_html__( 'Display Discover Icon', 'deux' ),
					'type'        => 'checkbox',
					'param_name'  => 'discover',
					'value'       => array(
						esc_html__( 'Yes', 'deux' ) => 'true',
					),
				),
				array(
					'heading'     => esc_html__( 'Amex', 'deux' ),
					'description' => esc_html__( 'Display Amex Icon', 'deux' ),
					'type'        => 'checkbox',
					'param_name'  => 'amex',
					'value'       => array(
						esc_html__( 'Yes', 'deux' ) => 'true',
					),
				),
				array(
					'heading'     => esc_html__( 'Jcb', 'deux' ),
					'description' => esc_html__( 'Display Jcb Icon', 'deux' ),
					'type'        => 'checkbox',
					'param_name'  => 'jcb',
					'value'       => array(
						esc_html__( 'Yes', 'deux' ) => 'true',
					),
				),
				array(
					'heading'     => esc_html__( 'Text Color', 'deux' ),
					'description' => esc_html__( 'Pick color scheme', 'deux' ),
					'param_name'  => 'color',
					'type'        => 'colorpicker',
					'value'       => '#333',
				),
			),
		) );
	}
}


new Deux_Shortcode_Credit_Card();