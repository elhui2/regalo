<?php
class Deux_Shortcode_Product_Slider1 extends WP_Shortcode_UI
{
	public $shortcode_name = 'product_slider1';

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * render the output of shotcode
	 * @param  array $atts
	 * @param  string $content
	 * @return mixed
	 */
	public function render( $atts, $content = null ){
		$atts = shortcode_atts( array(
			'ids'			=> '',
			'orderby'      	=> '',
			'order'     	=> '',
			'css_animation' => '',
			'el_class'      => '',
		), $atts );

		$css_class = array(
			'deux-carousel',
			'deux-product-slider1',
			'deux-products',
			$this->get_css_animation( $atts['css_animation'] ),
			$atts['el_class'],
		);
		if ( $atts['ids'] != '' ) :
	        $atts['ids'] = explode( ',', $atts['ids'] );
	    endif;
		ob_start();
	    $args = array(
	    	'post_type'           => 'product',
	    	'post__in'            => $atts['ids'],
	    	'order'               => $atts['order'],
	    	'orderby'             => $atts['orderby'],
	        'posts_per_page'      => 9999,

	    );

	    query_posts( $args );
		if( have_posts() ) :?>
			<div class="<?php echo esc_attr( implode( ' ', $css_class ) )?>" data-columns="1" data-autoplay="10000" data-loop="false">
				<div class='products'>
					<?php while ( have_posts() ) : the_post();?>
						<?php if ( has_post_thumbnail() ) : ?>
						<div class="carousel-item">
							<div class="entry-product">
								<div class="entry-image">
									<?php the_post_thumbnail('full'); ?>
								</div>
								<div class="entry-description">
									
									<h3 class="entry-title">
									    	<a href="<?php esc_url( the_permalink() ); ?>"><?php the_title() ?></a>
									</h3>
									<p class="entry-content">
										<?php echo esc_attr( wp_trim_words( get_the_excerpt( ), 30, '...')); ?>
									</p>
									<a class="deux-button button-type-light button-light line-hover" href="<?php esc_url( the_permalink() ); ?>" title="<?php the_title() ?>"><?php esc_html_e( "View Product", "deux" ); ?></a>
								</div>
							</div>
						</div>
					    <?php endif; ?>
					<?php endwhile;?>
				</div>

			</div>
			<?php 
				wp_reset_query();
			    
			    endif;

		return apply_filters( 'deux_product_slider1_html', ob_get_clean() );
	}

	/**
	 * render to visual composer
	 * @return mixed
	 */
	public function mapping(){

	 	$this->product_autocomplete('deux_'.$this->shortcode_name);

		vc_map( array(
			'name'        => esc_html__( 'Product Slider 1', 'deux' ),
			'description' => esc_html__( 'Product slider simple', 'deux' ),
			'base'        => 'deux_product_slider1',
			'category'    => esc_html__( 'Deux', 'deux' ),
			'params'      => array(
				array(
					'type' => 'autocomplete',
					'heading' => __( 'Products', 'deux' ),
					'param_name' => 'ids',
					'settings' => array(
						'multiple' => true,
						'sortable' => true,
						'unique_values' => true,
						// In UI show results except selected. NB! You should manually check values in backend
					),
					'save_always' => true,
					'description' => __( 'Enter List of Products', 'js_composer' ),
				),
		        array(
					"type" 			=> "dropdown",
					"heading" 		=> __("Orderby", "deux"),
					"param_name" 	=> "orderby",
					"admin_label" 	=> true,
					"value" 		=> array(
											__("none", "deux") => 'none',
											__("date", "deux") => 'date',
											__("name", "deux") => 'name',
											__("rand", "deux") => 'rand',
									   )
				),
		        array(
					"type" 			=> "dropdown",
					"heading" 		=> __("Order", "deux"),
					"param_name" 	=> "order",
					"admin_label" 	=> true,
					"value" 		=> array(
											' ' => ' ',
											__("Highest to lowest values", "deux") => 'DESC',
											__("lowest to highest values", "deux") => 'ASC',
									   )
				),
				vc_map_add_css_animation(),
				array(
					"type" 			=> "textfield",
					"heading" 		=> __("Extra Class", "deux"),
					"param_name" 	=> "ex_class",
				),
			),
		) );
	}
}


new Deux_Shortcode_Product_Slider1();