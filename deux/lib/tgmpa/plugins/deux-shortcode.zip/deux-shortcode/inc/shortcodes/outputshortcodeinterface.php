<?php

interface Deux_Shortcode_OutputShortcodeInterface 
{
	public function render( $atts, $content = null );
	public function mapping(); // if 3rd party visual composer.
}