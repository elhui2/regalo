<?php
class Deux_Shortcode_Icon_Box extends WP_Shortcode_UI
{
	public $shortcode_name = 'icon_box';

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * render the output of shotcode
	 * @param  array $atts
	 * @param  string $content
	 * @return mixed
	 */
	public function render( $atts, $content = null ){
		$atts = shortcode_atts( array(
			'icon_type'        => 'fontawesome',
			'icon_fontawesome' => 'fa fa-adjust',
			'icon_openiconic'  => 'vc-oi vc-oi-dial',
			'icon_typicons'    => 'typcn typcn-adjust-brightness',
			'icon_entypo'      => 'entypo-icon entypo-icon-note',
			'icon_linecons'    => 'vc_li vc_li-heart',
			'icon_monosocial'  => 'vc-mono vc-mono-fivehundredpx',
			'icon_material'    => 'vc-material vc-material-cake',
			'image'            => '',
			'style'            => 'normal',
			'title'            => esc_html__( 'I am Icon Box', 'deux' ),
			'css_animation'    => '',
			'el_class'         => '',
		), $atts );

		$css_class = array(
			'deux-icon-box',
			'icon-type-' . $atts['icon_type'],
			'icon-style-' . $atts['style'],
			$this->get_css_animation( $atts['css_animation'] ),
			$atts['el_class'],
		);

		if ( 'image' == $atts['icon_type'] ) {
			$image = wp_get_attachment_image_src( $atts['image'], 'full' );
			$icon  = $image ? sprintf( '<img alt="%s" src="%s">', esc_attr( $atts['title'] ), esc_url( $image[0] ) ) : '';
		} else {
			vc_icon_element_fonts_enqueue( $atts['icon_type'] );
			$icon = '<i class="' . esc_attr( $atts[ 'icon_' . $atts['icon_type'] ] ) . '"></i>';
		}

		return sprintf(
			'<div class="%s">
				<div class="box-icon">%s</div>
				<h3 class="box-title">%s</h3>
				<div class="box-content">%s</div>
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			$icon,
			esc_html( $atts['title'] ),
			$content
		);
	}

	/**
	 * render to visual composer
	 * @return mixed
	 */
	public function mapping(){
		vc_map( array(
			'name'        => esc_html__( 'Icon Box', 'deux' ),
			'description' => esc_html__( 'Information box with icon', 'deux' ),
			'base'        => 'deux_icon_box',
			'category'    => esc_html__( 'Deux', 'deux' ),
			'params'      => array(
				array(
					'heading'     => esc_html__( 'Icon library', 'deux' ),
					'description' => esc_html__( 'Select icon library.', 'deux' ),
					'param_name'  => 'icon_type',
					'type'        => 'dropdown',
					'value'       => array(
						esc_html__( 'Font Awesome', 'deux' ) => 'fontawesome',
						esc_html__( 'Open Iconic', 'deux' )  => 'openiconic',
						esc_html__( 'Typicons', 'deux' )     => 'typicons',
						esc_html__( 'Entypo', 'deux' )       => 'entypo',
						esc_html__( 'Linecons', 'deux' )     => 'linecons',
						esc_html__( 'Mono Social', 'deux' )  => 'monosocial',
						esc_html__( 'Material', 'deux' )     => 'material',
						esc_html__( 'Custom Image', 'deux' ) => 'image',
					),
				),
				array(
					'heading'     => esc_html__( 'Icon', 'deux' ),
					'description' => esc_html__( 'Select icon from library.', 'deux' ),
					'type'        => 'iconpicker',
					'param_name'  => 'icon_fontawesome',
					'value'       => 'fa fa-adjust',
					'settings'    => array(
						'emptyIcon'    => false,
						'iconsPerPage' => 4000,
					),
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => 'fontawesome',
					),
				),
				array(
					'heading'     => esc_html__( 'Icon', 'deux' ),
					'description' => esc_html__( 'Select icon from library.', 'deux' ),
					'type'        => 'iconpicker',
					'param_name'  => 'icon_openiconic',
					'value'       => 'vc-oi vc-oi-dial',
					'settings'    => array(
						'emptyIcon'    => false,
						'type'         => 'openiconic',
						'iconsPerPage' => 4000,
					),
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => 'openiconic',
					),
				),
				array(
					'heading'     => esc_html__( 'Icon', 'deux' ),
					'description' => esc_html__( 'Select icon from library.', 'deux' ),
					'type'        => 'iconpicker',
					'param_name'  => 'icon_typicons',
					'value'       => 'typcn typcn-adjust-brightness',
					'settings'    => array(
						'emptyIcon'    => false,
						'type'         => 'typicons',
						'iconsPerPage' => 4000,
					),
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => 'typicons',
					),
				),
				array(
					'heading'     => esc_html__( 'Icon', 'deux' ),
					'description' => esc_html__( 'Select icon from library.', 'deux' ),
					'type'        => 'iconpicker',
					'param_name'  => 'icon_entypo',
					'value'       => 'entypo-icon entypo-icon-note',
					'settings'    => array(
						'emptyIcon'    => false,
						'type'         => 'entypo',
						'iconsPerPage' => 4000,
					),
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => 'entypo',
					),
				),
				array(
					'heading'     => esc_html__( 'Icon', 'deux' ),
					'description' => esc_html__( 'Select icon from library.', 'deux' ),
					'type'        => 'iconpicker',
					'param_name'  => 'icon_linecons',
					'value'       => 'vc_li vc_li-heart',
					'settings'    => array(
						'emptyIcon'    => false,
						'type'         => 'linecons',
						'iconsPerPage' => 4000,
					),
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => 'linecons',
					),
				),
				array(
					'heading'     => esc_html__( 'Icon', 'deux' ),
					'description' => esc_html__( 'Select icon from library.', 'deux' ),
					'type'        => 'iconpicker',
					'param_name'  => 'icon_monosocial',
					'value'       => 'vc-mono vc-mono-fivehundredpx',
					'settings'    => array(
						'emptyIcon'    => false,
						'type'         => 'monosocial',
						'iconsPerPage' => 4000,
					),
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => 'monosocial',
					),
				),
				array(
					'heading'     => esc_html__( 'Icon', 'deux' ),
					'description' => esc_html__( 'Select icon from library.', 'deux' ),
					'type'        => 'iconpicker',
					'param_name'  => 'icon_material',
					'value'       => 'vc-material vc-material-cake',
					'settings'    => array(
						'emptyIcon'    => false,
						'type'         => 'material',
						'iconsPerPage' => 4000,
					),
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => 'material',
					),
				),
				array(
					'heading'     => esc_html__( 'Icon Image', 'deux' ),
					'description' => esc_html__( 'Upload icon image', 'deux' ),
					'type'        => 'attach_image',
					'param_name'  => 'image',
					'value'       => '',
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => 'image',
					),
				),
				array(
					'heading'     => esc_html__( 'Icon Style', 'deux' ),
					'description' => esc_html__( 'Select icon style', 'deux' ),
					'param_name'  => 'style',
					'type'        => 'dropdown',
					'value'       => array(
						esc_html__( 'Normal', 'deux' ) => 'normal',
						esc_html__( 'Circle', 'deux' ) => 'circle',
						esc_html__( 'Round', 'deux' )  => 'round',
					),
				),
				array(
					'heading'     => esc_html__( 'Title', 'deux' ),
					'description' => esc_html__( 'The box title', 'deux' ),
					'admin_label' => true,
					'param_name'  => 'title',
					'type'        => 'textfield',
					'value'       => esc_html__( 'I am Icon Box', 'deux' ),
				),
				array(
					'heading'     => esc_html__( 'Content', 'deux' ),
					'description' => esc_html__( 'The box title', 'deux' ),
					'holder'      => 'div',
					'param_name'  => 'content',
					'type'        => 'textarea_html',
					'value'       => esc_html__( 'I am icon box. Click edit button to change this text.', 'deux' ),
				),
				vc_map_add_css_animation(),
				array(
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'el_class',
				),
			),
		) );
	}
}


new Deux_Shortcode_Icon_Box();