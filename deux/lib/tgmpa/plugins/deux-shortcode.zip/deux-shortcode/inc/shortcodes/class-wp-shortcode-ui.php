<?php
/**
* The class is helper parent for any kind of shortcode,
* create your own shortcode in class inheritance.
*/
class WP_Shortcode_UI implements Deux_Shortcode_OutputShortcodeInterface
{
	protected $shortcode_name = '';
	
	public function __construct()
	{
		add_shortcode( "deux_{$this->shortcode_name}", array( $this, 'render' ) );
		add_action( 'vc_before_init', array( $this, 'mapping' ) );

		/*ajax load product*/
		add_action( 'wp_ajax_nopriv_deux_load_products', array( $this, 'ajax_load_products' ) );
		add_action( 'wp_ajax_deux_load_products', array( $this, 'ajax_load_products' ) );
	}

	/**
	 * render the shortcode
	 * @param array $atts
	 * @return void
	 */
	public function render( $atts, $content = null ) 
	{
		return '';
	}

	public function mapping(){}

	function product_autocomplete($shortcode_name){
		$woo_autocomplete = new Vc_Vendor_Woocommerce(); 
		//Filters For autocomplete param:
		//For suggestion: vc_autocomplete_[shortcode_name]_[param_name]_callback
		add_filter( "vc_autocomplete_{$shortcode_name}_ids_callback", array(
			$woo_autocomplete,
			'productIdAutocompleteSuggester',
		), 10, 1 ); // Get suggestion(find). Must return an array
		add_filter( "vc_autocomplete_{$shortcode_name}_ids_render", array(
			$woo_autocomplete,
			'productIdAutocompleteRender',
		), 10, 1 ); // Render exact product. Must return an array (label,value)
		//For param: ID default value filter
	}

	/**
	 * Get CSS classes for animation
	 *
	 * @param string $css_animation
	 *
	 * @return string
	 */
	function get_css_animation( $css_animation ) {
		$output = '';

		if ( '' !== $css_animation ) {
			wp_enqueue_script( 'waypoints' );
			wp_enqueue_style( 'animate-css' );
			$output = ' wpb_animate_when_almost_visible wpb_' . $css_animation . ' ' . $css_animation;
		}

		return $output;
	}

	/**
	 * Loop over found products.
	 *
	 * @param  array  $atts
	 * @param  string $loop_name
	 *
	 * @return string
	 * @internal param array $columns
	 */
	function product_loop( $atts, $loop_name = 'deux_product_grid' ) {
		global $woocommerce_loop;

		$query_args = $this->get_query( $atts );

		if ( isset( $atts['type'] ) && 'top_rated' == $atts['type'] ) {
			add_filter( 'posts_clauses', array( 'WC_Shortcodes', 'order_by_rating_post_clauses' ) );
		}

		$products = new WP_Query( $query_args );

		if ( isset( $atts['type'] ) && 'new' == $atts['type'] ) {
			$query_args['meta_query'][] = array(
				'key'   => '_is_new',
				'value' => 'yes',
			);
			unset( $query_args['date_query'] );
			unset( $query_args['update_post_meta_cache'] );

			$new_products = new WP_Query( $query_args );

			if ( $new_products->have_posts() ) {
				$products->posts = array_merge( $products->posts, $new_products->posts );
				$products->post_count = count( $products->posts );
			}
		}

		if ( isset( $atts['type'] ) && 'top_rated' == $atts['type'] ) {
			remove_filter( 'posts_clauses', array( 'WC_Shortcodes', 'order_by_rating_post_clauses' ) );
		}

		$woocommerce_loop['name'] = $loop_name;
		$columns                  = isset( $atts['columns'] ) ? absint( $atts['columns'] ) : null;

		if ( $columns ) {
			$woocommerce_loop['columns'] = $columns;
		}

		ob_start();

		if ( $products->have_posts() ) {
			woocommerce_product_loop_start();

			while ( $products->have_posts() ) : $products->the_post();
				wc_get_template_part( 'content', 'product' );
			endwhile; // end of the loop.

			woocommerce_product_loop_end();
		}

		$return = '<div class="woocommerce columns-' . $columns . '">' . ob_get_clean() . '</div>';

		if ( isset( $atts['load_more'] ) && $atts['load_more'] && $products->max_num_pages > 1 ) {
			$paged = max( 1, $products->get( 'paged' ) );
			$type  = isset( $atts['type'] ) ? $atts['type'] : 'recent';

			if ( $paged < $products->max_num_pages ) {
				$button = sprintf(
					'<div class="navigation posts-navigation ajax-navigation">
						<a href="#" class="ajax-load-products" data-page="%s" data-columns="%s" data-per_page="%s" data-type="%s" data-category="%s" data-nonce="%s" rel="nofollow">
							<span class="button-text"> 
								<span class="bubble">
									<span class="dot"></span> 
								</span>
								<span class="bubble">
									<span class="dot"></span> 
								</span>
								<span class="bubble">
									<span class="dot"></span> 
								</span>
							</span>

							<span class="loading-icon">
								<span class="bubble">
									<span class="dot"><span class="dot__color dot__color--1"></span></span>
								</span>
								<span class="bubble">
									<span class="dot"><span class="dot__color dot__color--2"></span></span>
								</span>
								<span class="bubble">
									<span class="dot"><span class="dot__color dot__color--3"></span></span>
								</span>
							</span>
						</a>
					</div>',
					esc_attr( $paged + 1 ),
					esc_attr( $columns ),
					esc_attr( $query_args['posts_per_page'] ),
					esc_attr( $type ),
					isset( $atts['category'] ) ? esc_attr( $atts['category'] ) : '',
					esc_attr( wp_create_nonce( 'deux_get_products' ) )					
				);

				$return .= $button;
			}
		}

		woocommerce_reset_loop();
		wp_reset_postdata();

		return $return;
	}

	/**
	 * Get category for auto complete field
	 *
	 * @param string $taxonomy Taxnomy to get terms
	 *
	 * @return array
	 */
	function get_terms( $taxonomy = 'product_cat' ) {
		// We don't want to query all terms again
		if ( isset( $this->terms[ $taxonomy ] ) ) {
			return $this->terms[ $taxonomy ];
		}

		$cats = get_terms( $taxonomy );
		if ( ! $cats || is_wp_error( $cats ) ) {
			return array();
		}

		$categories = array();
		foreach ( $cats as $cat ) {
			$categories[] = array(
				'label' => $cat->name,
				'value' => $cat->slug,
				'group' => 'category',
			);
		}

		// Store this in order to avoid double query this
		$this->terms[ $taxonomy ] = $categories;

		return $categories;
	}


	/**
	 * Build query args from shortcode attributes
	 *
	 * @param array $atts
	 *
	 * @return array
	 */
	function get_query( $atts ) {
		$args = array(
			'post_type'              => 'product',
			'post_status'            => 'publish',
			'ignore_sticky_posts'    => 1,
			'posts_per_page'         => $atts['per_page'],
			'meta_query'             => WC()->query->get_meta_query(),
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
		);

		if( version_compare( WC()->version, '3.0.0', '>=' ) ) {
			$args['tax_query'] = WC()->query->get_tax_query();
		}

		// Improve performance
		if ( ! isset( $atts['load_more'] ) || ! $atts['load_more'] ) {
			$args['no_found_rows'] = true;
		}

		if ( ! empty( $atts['category'] ) ) {
			$args['product_cat'] = $atts['category'];
			unset( $args['update_post_term_cache'] );
		}

		if ( ! empty( $atts['page'] ) ) {
			$args['paged'] = absint( $atts['page'] );
		}

		if ( isset( $atts['type'] ) ) {
			switch ( $atts['type'] ) {
				case 'featured':
					if( version_compare( WC()->version, '3.0.0', '<' ) ) {
						$args['meta_query'][] = array(
							'key'   => '_featured',
							'value' => 'yes',
						);
					} else {
						$args['tax_query'][] = array(
							'taxonomy' => 'product_visibility',
							'field'    => 'name',
							'terms'    => 'featured',
							'operator' => 'IN',
						);
					}

					unset( $args['update_post_meta_cache'] );
					break;

				case 'sale':
					$args['post__in'] = array_merge( array( 0 ), wc_get_product_ids_on_sale() );
					break;

				case 'best_sellers':
					$args['meta_key'] = 'total_sales';
					$args['orderby']  = 'meta_value_num';
					unset( $args['update_post_meta_cache'] );
					break;

				case 'new':
					$newness = intval( deux_get_option( 'product_newness' ) );

					if ( $newness > 0 ) {
						$args['date_query'] = array(
							'after' => date( 'Y-m-d', strtotime( '-' . $newness . ' days' ) )
						);
					}
					break;

				case 'top_rated':
					break;
			}
		}

		return $args;
	}

	/**
	 * Ajax load products
	 */
	function ajax_load_products() {
		check_ajax_referer( 'deux_get_products', 'nonce' );

		$atts = array(
			'load_more' => true,
			'type'      => isset( $_POST['type'] ) ? $_POST['type'] : '',
			'page'      => isset( $_POST['page'] ) ? intval( $_POST['page'] ) : 1,
			'per_page'  => isset( $_POST['per_page'] ) ? intval( $_POST['per_page'] ) : 10,
		);

		if ( isset( $_POST['columns'] ) ) {
			$atts['columns'] = intval( $_POST['columns'] );
		}

		if ( isset( $_POST['category'] ) ) {
			$atts['category'] = trim( $_POST['category'] );
		}

		$data = $this->product_loop( $atts );

		wp_send_json_success( $data );
	}

	/**
	 * Get coordinates
	 *
	 * @param string $address
	 * @param bool   $refresh
	 *
	 * @return array
	 */
	function get_coordinates( $address, $key = '', $refresh = false ) {
		$address_hash = md5( $address );
		$coordinates  = get_transient( $address_hash );
		$results      = array( 'lat' => '', 'lng' => '' );

		if ( $refresh || $coordinates === false ) {
			$args     = array( 'address' => urlencode( $address ), 'sensor' => 'false', 'key' => $key );
			$url      = add_query_arg( $args, 'https://maps.googleapis.com/maps/api/geocode/json' );
			$response = wp_remote_get( $url );

			if ( is_wp_error( $response ) ) {
				$results['error'] = esc_html__( 'Can not connect to Google Maps APIs', 'sober' );

				return $results;
			}

			$data = wp_remote_retrieve_body( $response );

			if ( is_wp_error( $data ) ) {
				$results['error'] = esc_html__( 'Can not connect to Google Maps APIs', 'sober' );

				return $results;
			}

			if ( $response['response']['code'] == 200 ) {
				$data = json_decode( $data );

				if ( $data->status === 'OK' ) {
					$coordinates = $data->results[0]->geometry->location;

					$results['lat']     = $coordinates->lat;
					$results['lng']     = $coordinates->lng;
					$results['address'] = (string) $data->results[0]->formatted_address;

					// cache coordinates for 3 months
					set_transient( $address_hash, $results, 3600 * 24 * 30 * 3 );
				} elseif ( $data->status === 'ZERO_RESULTS' ) {
					$results['error'] = esc_html__( 'No location found for the entered address.', 'sober' );
				} elseif ( $data->status === 'INVALID_REQUEST' ) {
					$results['error'] = esc_html__( 'Invalid request. Did you enter an address?', 'sober' );
				} else {
					$results['error'] = $data->error_message;
				}
			} else {
				$results['error'] = esc_html__( 'Unable to contact Google API service.', 'sober' );
			}
		} else {
			$results = $coordinates; // return cached results
		}

		return $results;
	}
	
}