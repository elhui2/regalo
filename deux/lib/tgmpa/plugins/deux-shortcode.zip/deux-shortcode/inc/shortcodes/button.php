<?php
class Deux_Shortcode_Button extends WP_Shortcode_UI
{
	public $shortcode_name = 'button';

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * render the output of shotcode
	 * @param  array $atts
	 * @param  string $content
	 * @return mixed
	 */
	public function render( $atts, $content = null ){
		$atts = shortcode_atts( array(
			'label'         			=> '',
			'link'          			=> '',
			'style'         			=> 'normal',
			'size'          			=> 'normal',
			'align'         			=> 'inline',
			'color'         			=> 'dark',
			'color_bg_button'   		=> '',
			'color_text_button' 		=> '',
			'color_bg_button_hover' 	=> '',
			'color_text_button_hover' 	=> '',
			'css_animation' 			=> '',
			'el_class'      			=> '',
		), $atts );

		$attributes = array();

		$css_class = array(
			'deux-button',
			'button-type-' . $atts['style'],
			'button-color-' . $atts['color'],
			'align-' . $atts['align'],
			$this->get_css_animation( $atts['css_animation'] ),
			$atts['el_class'],
		);

		if ( 'light' == $atts['style'] ) {
			$css_class[] = 'button-light line-hover';
		} else {
			$css_class[] = 'button';
			$css_class[] = $atts['size'];
			$css_class[] = 'button-' . $atts['size'];
		}

		$style = '';
		$data = '';
		if ('custom' == $atts['style']) {
			$style = sprintf('style="background-color:%s;color:%s"',
								$atts['color_bg_button'], 
								$atts['color_text_button'] 
							);
			$data = sprintf('data-bg="%s" data-text="%s" data-bg-hover="%s" data-text-hover="%s"',
								$atts['color_bg_button'], 
								$atts['color_text_button'], 
								$atts['color_bg_button_hover'], 
								$atts['color_text_button_hover'] 
							);
		}

		if ( function_exists( 'vc_build_link' ) && ! empty( $atts['link'] ) ) {
			$link = vc_build_link( $atts['link'] );

			if ( ! empty( $link['url'] ) ) {
				$attributes['href'] = $link['url'];
			}

			if ( ! empty( $link['title'] ) ) {
				$attributes['title'] = $link['title'];
			}

			if ( ! empty( $link['target'] ) ) {
				$attributes['target'] = $link['target'];
			}

			if ( ! empty( $link['rel'] ) ) {
				$attributes['rel'] = $link['rel'];
			}
		}

		$attributes['class'] = implode( ' ', $css_class );
		$attr                = array();

		foreach ( $attributes as $name => $value ) {
			$attr[] = $name . '="' . esc_attr( $value ) . '"';
		}

		$button = sprintf(
			'<%1$s %2$s %3$s %4$s>%5$s</%1$s>',
			empty( $attributes['href'] ) ? 'span' : 'a',
			implode( ' ', $attr ),
			$style,
			$data,
			esc_html( $atts['label'] )
		);

		if ( 'center' == $atts['align'] ) {
			return '<div class="deux-button-wrapper text-center">' . $button . '</div>';
		}

		return $button;
	}

	/**
	 * render to visual composer
	 * @return mixed
	 */
	public function mapping(){
		vc_map( array(
			'name'        => esc_html__( 'Button', 'deux' ),
			'description' => esc_html__( 'Button in style', 'deux' ),
			'base'        => 'deux_button',
			'category'    => esc_html__( 'Deux', 'deux' ),
			'params'      => array(
				array(
					'heading'     => esc_html__( 'Text', 'deux' ),
					'description' => esc_html__( 'Enter button text', 'deux' ),
					'admin_label' => true,
					'type'        => 'textfield',
					'param_name'  => 'label',
				),
				array(
					'heading'    => esc_html__( 'URL (Link)', 'deux' ),
					'type'       => 'vc_link',
					'param_name' => 'link',
				),
				array(
					'heading'     => esc_html__( 'Style', 'deux' ),
					'description' => esc_html__( 'Select button style', 'deux' ),
					'param_name'  => 'style',
					'type'        => 'dropdown',
					'value'       => array(
						esc_html__( 'Normal', 'deux' )  => 'normal',
						esc_html__( 'Outline', 'deux' ) => 'outline',
						esc_html__( 'Light', 'deux' )   => 'light',
						esc_html__( 'Custom', 'deux' )  => 'custom',
					),
				),
				array(
					'heading'     => esc_html__( 'Size', 'deux' ),
					'description' => esc_html__( 'Select button size', 'deux' ),
					'param_name'  => 'size',
					'type'        => 'dropdown',
					'value'       => array(
						esc_html__( 'Normal', 'deux' ) => 'normal',
						esc_html__( 'Large', 'deux' )  => 'large',
						esc_html__( 'Small', 'deux' )  => 'small',
					),
					'dependency'  => array(
						'element' => 'style',
						'value'   => array( 'normal', 'outline' ),
					),
				),
				array(
					'heading'     => esc_html__( 'Color', 'deux' ),
					'description' => esc_html__( 'Select button color', 'deux' ),
					'param_name'  => 'color',
					'type'        => 'dropdown',
					'value'       => array(
						esc_html__( 'Dark', 'deux' )  => 'dark',
						esc_html__( 'White', 'deux' ) => 'white',
					),
					'dependency'  => array(
						'element' => 'style',
						'value'   => array( 'outline' ),
					),
				),
				array(
					'heading'     => esc_html__( 'Background Color', 'deux' ),
					'description' => esc_html__( 'Select background button color', 'deux' ),
					'param_name'  => 'color_bg_button',
					'type'        => 'colorpicker',
					'dependency'  => array(
						'element' => 'style',
						'value'   => array( 'custom' ),
					),
				),
				array(
					'heading'     => esc_html__( 'Text Color', 'deux' ),
					'description' => esc_html__( 'Select text button color', 'deux' ),
					'param_name'  => 'color_text_button',
					'type'        => 'colorpicker',
					'dependency'  => array(
						'element' => 'style',
						'value'   => array( 'custom' ),
					),
				),
				array(
					'heading'     => esc_html__( 'Background Color Hover', 'deux' ),
					'description' => esc_html__( 'Select background button color hover', 'deux' ),
					'param_name'  => 'color_bg_button_hover',
					'type'        => 'colorpicker',
					'dependency'  => array(
						'element' => 'style',
						'value'   => array( 'custom' ),
					),
				),
				array(
					'heading'     => esc_html__( 'Text Color Hover', 'deux' ),
					'description' => esc_html__( 'Select text button color hover', 'deux' ),
					'param_name'  => 'color_text_button_hover',
					'type'        => 'colorpicker',
					'dependency'  => array(
						'element' => 'style',
						'value'   => array( 'custom' ),
					),
				),
				array(
					'heading'     => esc_html__( 'Alignment', 'deux' ),
					'description' => esc_html__( 'Select button alignment', 'deux' ),
					'param_name'  => 'align',
					'type'        => 'dropdown',
					'value'       => array(
						esc_html__( 'Inline', 'deux' ) => 'inline',
						esc_html__( 'Left', 'deux' )   => 'left',
						esc_html__( 'Center', 'deux' ) => 'center',
						esc_html__( 'Right', 'deux' )  => 'right',
					),
				),
				vc_map_add_css_animation(),
				array(
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
					'param_name'  => 'el_class',
					'type'        => 'textfield',
					'value'       => '',
				),
			),
		) );
	}
}


new Deux_Shortcode_Button();