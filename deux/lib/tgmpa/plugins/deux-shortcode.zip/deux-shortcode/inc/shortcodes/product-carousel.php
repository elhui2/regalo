<?php
class Deux_Shortcode_Product_Carousel extends WP_Shortcode_UI
{
	public $shortcode_name = 'product_carousel';

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * render the output of shotcode
	 * @param  array $atts
	 * @param  string $content
	 * @return mixed
	 */
	public function render( $atts, $content = null ){
		$atts = shortcode_atts( array(
			'per_page'      => 15,
			'columns'       => 4,
			'type'          => 'recent',
			'category'      => '',
			'autoplay'      => 5000,
			'loop'          => false,
			'css_animation' => '',
			'el_class'      => '',
		), $atts );

		$css_class = array(
			'deux-product-carousel',
			'deux-carousel',
			'deux-products',
			$this->get_css_animation( $atts['css_animation'] ),
			$atts['el_class'],
		);

		return sprintf(
			'<div class="%s" data-columns="%s" data-autoplay="%s" data-loop="%s">%s</div>',
			esc_attr( implode( ' ', $css_class ) ),
			esc_attr( $atts['columns'] ),
			esc_attr( $atts['autoplay'] ),
			esc_attr( $atts['loop'] ),
			$this->product_loop( $atts )
		);
	}

	/**
	 * render to visual composer
	 * @return mixed
	 */
	public function mapping(){
		vc_map( array(
			'name'        => esc_html__( 'Product Carousel', 'deux' ),
			'description' => esc_html__( 'Product carousel slider', 'deux' ),
			'base'        => 'deux_product_carousel',
			'category'    => esc_html__( 'Deux', 'deux' ),
			'params'      => array(
				array(
					'heading'     => esc_html__( 'Number Of Products', 'deux' ),
					'description' => esc_html__( 'Total number of products you want to show', 'deux' ),
					'param_name'  => 'number',
					'type'        => 'textfield',
					'value'       => 15,
				),
				array(
					'heading'     => esc_html__( 'Columns', 'deux' ),
					'description' => esc_html__( 'Display products in how many columns', 'deux' ),
					'param_name'  => 'columns',
					'type'        => 'dropdown',
					'value'       => array(
						esc_html__( '3 Columns', 'deux' ) => 3,
						esc_html__( '4 Columns', 'deux' ) => 4,
						esc_html__( '5 Columns', 'deux' ) => 5,
						esc_html__( '6 Columns', 'deux' ) => 6,
					),
				),
				array(
					'heading'     => esc_html__( 'Product Type', 'deux' ),
					'description' => esc_html__( 'Select product type you want to show', 'deux' ),
					'param_name'  => 'type',
					'type'        => 'dropdown',
					'value'       => array(
						esc_html__( 'Recent Products', 'deux' )       => 'recent',
						esc_html__( 'Featured Products', 'deux' )     => 'featured',
						esc_html__( 'Sale Products', 'deux' )         => 'sale',
						esc_html__( 'Best Selling Products', 'deux' ) => 'best_sellers',
						esc_html__( 'Top Rated Products', 'deux' )    => 'top_rated',
					),
				),
				array(
					'heading'     => esc_html__( 'Categories', 'deux' ),
					'description' => esc_html__( 'Select what categories you want to use. Leave it empty to use all categories.', 'deux' ),
					'param_name'  => 'category',
					'type'        => 'autocomplete',
					'value'       => '',
					'settings'    => array(
						'multiple' => true,
						'sortable' => true,
						'values'   => $this->get_terms(),
					),
				),
				array(
					'heading'     => esc_html__( 'Auto Play', 'deux' ),
					'description' => esc_html__( 'Auto play speed in miliseconds. Enter "0" to disable auto play.', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'autoplay',
					'value'       => 5000,
				),
				array(
					'heading'     => esc_html__( 'Loop', 'deux' ),
					'type'        => 'checkbox',
					'param_name'  => 'loop',
					'value'       => array( esc_html__( 'Yes', 'deux' ) => 'yes' ),
				),
				vc_map_add_css_animation(),
				array(
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
					'param_name'  => 'el_class',
					'type'        => 'textfield',
					'value'       => '',
				),
			),
		) );
	}
}


new Deux_Shortcode_Product_Carousel();