<?php
class Deux_Shortcode_Product extends WP_Shortcode_UI
{
	public $shortcode_name = 'product';

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * render the output of shotcode
	 * @param  array $atts
	 * @param  string $content
	 * @return mixed
	 */
	public function render( $atts, $content = null ){
		$atts = shortcode_atts( array(
			'image'         => '',
			'title'         => '',
			'color'         => '',
			'price'         => '',
			'link'          => '',
			'css_animation' => '',
			'el_class'      => '',
		), $atts );

		$css_class = array(
			'deux-product',
			$this->get_css_animation( $atts['css_animation'] ),
			$atts['el_class'],
		);

		$image = wp_get_attachment_image_src( $atts['image'], 'full' );
		$image = sprintf( '<img alt="%s" src="%s">', esc_attr( $atts['title'] ), esc_url( $image[0] ) );
		$link  = vc_build_link( $atts['link'] );

		$price = floatval( $atts['price'] );

		if ( shortcode_exists( 'woocs_show_custom_price' ) ) {
			$price = do_shortcode( '[woocs_show_custom_price value="' . $price . '"]' );
		} else {
			$price = wc_price( $price );
		}

		return sprintf(
			'<div class="%s">
				<a href="%s" target="%s" rel="%s">
					<div class="product-image">
						%s
					</div>
					<div class="product-info" style="color: %s">
						<h3 class="product-title">%s</h3>
						<div class="product-subtitle">%s</div>
						<div class="product-price">
							<span class="price">%s</span>
						</div>
					</div>
				</a>
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			esc_url( $link['url'] ),
			esc_url( $link['target'] ),
			esc_url( $link['rel'] ),
			$image,
			esc_attr( $atts['color'] ),
			esc_html( $atts['title'] ),
			$content,
			$price
		);
	}

	/**
	 * render to visual composer
	 * @return mixed
	 */
	public function mapping(){
		vc_map( array(
			'name'        => esc_html__( 'Product', 'deux' ),
			'description' => esc_html__( 'Display single product banner', 'deux' ),
			'base'        => 'deux_product',
			'category'    => esc_html__( 'Deux', 'deux' ),
			'params'      => array(
				array(
					'heading'     => esc_html__( 'Images', 'deux' ),
					'description' => esc_html__( 'Upload a product image', 'deux' ),
					'param_name'  => 'image',
					'type'        => 'attach_image',
					'value'       => '',
				),
				array(
					'heading'     => esc_html__( 'Product Name', 'deux' ),
					'description' => esc_html__( 'Enter product name', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'title',
					'admin_label' => true,
				),
				array(
					'heading'     => esc_html__( 'Product Category', 'deux' ),
					'description' => esc_html__( 'Enter product category', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'content',
				),
				array(
					'heading'     => esc_html__( 'Product Price', 'deux' ),
					'description' => esc_html__( 'Enter product price. Only allow number.', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'price',
				),
				array(
					'heading'     => esc_html__( 'Text Color', 'deux' ),
					'description' => esc_html__( 'Pick color scheme', 'deux' ),
					'param_name'  => 'color',
					'type'        => 'colorpicker',
					'value'       => '#fff',
				),
				array(
					'heading'    => esc_html__( 'Product URL', 'deux' ),
					'type'       => 'vc_link',
					'param_name' => 'link',
				),
				vc_map_add_css_animation(),
				array(
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
					'param_name'  => 'el_class',
					'type'        => 'textfield',
				),
			),
		) );
	}
}


new Deux_Shortcode_Product();