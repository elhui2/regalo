<?php
class Deux_Shortcode_Product_Slider2 extends WP_Shortcode_UI
{
	public $shortcode_name = 'product_slider2';

	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * render the output of shotcode
	 * @param  array $atts
	 * @param  string $content
	 * @return mixed
	 */
	public function render( $atts, $content = null ){
		$atts = shortcode_atts( array(
			'ids'			=> '',
			'orderby'      	=> '',
			'order'     	=> '',
			'css_animation' => '',
			'el_class'      => '',
		), $atts );

		$css_class = array(
			'deux-product-slider2',
			$this->get_css_animation( $atts['css_animation'] ),
			$atts['el_class'],
		);

		if ( $atts['ids'] != '' ) :
	        $atts['ids'] = explode( ',', $atts['ids'] );
	    endif;


		ob_start();


	    $args = array(
	    	'post_type'           => 'product',
	    	'post__in'            => $atts['ids'],
	    	'order'               => $atts['order'],
	    	'orderby'             => $atts['orderby'],
	        'posts_per_page'      => 9999,

	    );
	    query_posts( $args );
	    global $product;
		if( have_posts() ) :?>
			<div class="deux-product-slider2">
				<div id="ps-container" class="ps-container">
					<div class="ps-contentwrapper">
						
						<?php while ( have_posts() ) : the_post();?>

						<div class="ps-content">
							<h2><?php the_title() ?></h2>
							<span class="ps-price">
								<?php 
									 $product = wc_get_product();
									echo $product->get_price_html();
								?>
							</span>
							<p><?php echo esc_attr( wp_trim_words( get_the_excerpt( ), 40, '...')); ?></p>
							<a href="<?php esc_url( the_permalink() ); ?>"><?php esc_html_e( "View Product", "lostile" ); ?></a>
						</div>
						<?php endwhile;?>
						
					</div><!-- /ps-contentwrapper -->
					<div class="ps-slidewrapper">
					
						<div class="ps-slides">
							<?php while ( have_posts() ) : the_post();?>
							<div style="background-image:url(<?php echo get_the_post_thumbnail_url( get_the_ID(), 'full' ); ?>);"></div>
							<?php endwhile;?>
						</div>
						
						<nav>
							<a href="#" class="ps-prev" ></a>
							<a href="#" class="ps-next" ></a>
						</nav>
						
					</div><!-- /ps-slidewrapper -->
				</div><!-- /ps-container -->
			</div><!-- /ps-container -->
			<div class="clearfix"></div>


	<?php 
		wp_reset_query();
	    
	    endif;

	    return apply_filters( 'lostile_slider_product_2_html', ob_get_clean() );
	}

	/**
	 * render to visual composer
	 * @return mixed
	 */
	public function mapping(){
	 	$this->product_autocomplete('deux_'.$this->shortcode_name);

		vc_map( array(
			'name'        => esc_html__( 'Product Slider 2', 'deux' ),
			'description' => esc_html__( 'Product slider modern', 'deux' ),
			'base'        => 'deux_product_slider2',
			'category'    => esc_html__( 'Deux', 'deux' ),
			'params'      => array(
				array(
					'type' => 'autocomplete',
					'heading' => __( 'Products', 'deux' ),
					'param_name' => 'ids',
					'settings' => array(
						'multiple' => true,
						'sortable' => true,
						'unique_values' => true,
						// In UI show results except selected. NB! You should manually check values in backend
					),
					'save_always' => true,
					'description' => __( 'Enter List of Products', 'js_composer' ),
				),
		        array(
					"type" 			=> "dropdown",
					"heading" 		=> __("Orderby", "deux"),
					"param_name" 	=> "orderby",
					"admin_label" 	=> true,
					"value" 		=> array(
											__("none", "deux") => 'none',
											__("date", "deux") => 'date',
											__("name", "deux") => 'name',
											__("rand", "deux") => 'rand',
									   )
				),
		        array(
					"type" 			=> "dropdown",
					"heading" 		=> __("Order", "deux"),
					"param_name" 	=> "order",
					"admin_label" 	=> true,
					"value" 		=> array(
											' ' => ' ',
											__("Highest to lowest values", "deux") => 'DESC',
											__("lowest to highest values", "deux") => 'ASC',
									   )
				),
				vc_map_add_css_animation(),
				array(
					"type" 			=> "textfield",
					"heading" 		=> __("Extra Class", "deux"),
					"param_name" 	=> "ex_class",
				),
			),
		) );
	}
}


new Deux_Shortcode_Product_Slider2();