<?php
/**
 * Meta information for the share and tag.
 * 
 * @package deux 
 */

if ( !function_exists( 'deux_share_meta_property' ) ) :
	/**
	 * Display sharing meta property
	 * @return void
	 */
    function deux_share_meta_property() {
        global $post;
        if ( !is_object( $post ) ) { return; }

        $image       = get_the_post_thumbnail_url( $post->ID, 'full' );
        $description = is_singular() ? trim( wp_trim_words( strip_shortcodes( strip_tags( get_post()->post_content ) ), 35, '' ), '.!?,;:-' ) . '&hellip;' : get_bloginfo( 'description' );

        if ( has_post_thumbnail() ): ?>
			
			<meta itemprop="name" content="<?php the_title(); ?>">
			<meta itemprop="description" content="<?php echo $description; ?>">
			<meta itemprop="image" content="<?php echo esc_url_raw( $image ); ?>">
            <!-- Facebook Share Meta-->
            <meta property="og:title" content="<?php the_title(); ?>" />
            <meta property="og:image" content="<?php echo esc_url_raw( $image ); ?>" />
            <meta property="og:image:url" content="<?php echo esc_url_raw( $image ); ?>">
            <meta property="og:url" content="<?php echo esc_url( get_the_permalink() ); ?>" />
            <meta property="og:description" content="<?php echo $description; ?>" />
            <!-- Twitter Share Meta -->
            <meta name="twitter:url" content="<?php echo esc_url( get_the_permalink() ); ?>">
            <meta name="twitter:title" content="<?php the_title(); ?>">
            <meta name="twitter:description" content="<?php echo $description; ?>">
            <meta name="twitter:image" content="<?php echo esc_url_raw( $image ); ?>">
            <meta name="twitter:image:src" content="<?php echo esc_url_raw( $image ); ?>">


        <?php endif;
    }

    add_action('wp_head', 'deux_share_meta_property');
endif;


/**
 * the share
 * 
 * @package deux 
 */
if( ! function_exists( 'deux_social_share' ) ) {

    function deux_social_share(){ ?>
        <ul class="share-container">
                    
            <?php  
            $src = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), false, '');
            $encode_ent = urlencode( html_entity_decode( get_the_title(), ENT_COMPAT, 'UTF-8') );
            $tw_url = 'http://twitter.com/share?text=' . htmlspecialchars( $encode_ent, ENT_COMPAT, 'UTF-8' ) . '&amp;url=' .get_the_permalink(get_the_ID());
            $pinterest_url = 'https://pinterest.com/pin/create/button/?url=' . get_the_permalink(get_the_ID()) . '&amp;media='. $src[0] .'&amp;description=' . htmlspecialchars( $encode_ent, ENT_COMPAT, 'UTF-8'); ?>
            <li>
                <a class="center social-icon si-light  si-rounded si-facebook" href="<?php echo esc_url( 'https://www.facebook.com/sharer/sharer.php?u='. get_the_permalink(get_the_ID()) ); ?>" target="_blank">
                    <i class="fa fa-facebook"></i>
                    <i class="fa fa-facebook"></i>
                </a>

            </li>
            <li>
                <a class="center social-icon si-light si-rounded si-twitter" href="<?php echo esc_url( $tw_url ); ?>" target="_blank">
                    <i class="fa fa-twitter"></i>
                    <i class="fa fa-twitter"></i>
                </a>

            </li>
            <li>
                <a class="center social-icon si-light si-rounded si-pinterest" href="<?php echo esc_url( $pinterest_url ) ?>" target="_blank">
                    <i class="fa fa-pinterest"></i>
                    <i class="fa fa-pinterest"></i>
                </a>
                        
            </li>
            <li>
                <a class="center social-icon si-light si-rounded si-email3" href="<?php echo esc_url( 'mailto:?subject='. get_the_permalink(get_the_ID()) ); ?>" target="_top">
                    <i class="fa fa-envelope"></i>
                    <i class="fa fa-envelope"></i>
                </a>
            </li>
        </ul>

        <?php 

    }

}

/**
 * Product share
 * Share on Facebook, Twitter, Pinterest, Mail
 */
if ( ! function_exists( 'deux_wc_share' ) ) {

    function deux_wc_share( $socials ) {
        
        if ( empty( $socials ) ) {
            return;
        }
        ?>

        <div class="product-share clearfix">
            <span class="screen-reader-text"><?php esc_html_e( 'Share','deux' ) ?></span>

            <?php if ( in_array( 'facebook', $socials ) ) : ?>

                <a href="<?php echo esc_url( add_query_arg( array( 'u' => rawurlencode( get_permalink() ) ), 'https://www.facebook.com/sharer/sharer.php' ) ) ?>" target="_blank" class="social-icon si-light si-rounded si-small si-facebook">
                    <i class="fa fa-facebook"></i>
                    <i class="fa fa-facebook"></i>
                </a>
            <?php endif; ?>

            <?php if ( in_array( 'twitter', $socials ) ) : ?>
                <a href="<?php echo esc_url( add_query_arg( array(
                    'url'  => rawurlencode( get_permalink() ),
                    'text' => rawurlencode( get_the_title() ),
                ), 'https://twitter.com/intent/tweet' ) ) ?>" target="_blank" class="social-icon si-light si-rounded si-small si-twitter">
                    <i class="fa fa-twitter"></i>
                    <i class="fa fa-twitter"></i>
                </a>
            <?php endif; ?>

            <?php if ( in_array( 'pinterest', $socials ) ) : ?>
                <a href="<?php echo esc_url( add_query_arg( array(
                    'url'         => rawurlencode( get_permalink() ),
                    'media'       => get_the_post_thumbnail_url(),
                    'description' => rawurlencode( get_the_title() ),
                ), 'http://pinterest.com/pin/create/button' ) ) ?>" target="_blank" class="social-icon si-light si-rounded si-small si-pinterest">
                    <i class="fa fa-pinterest-p"></i>
                    <i class="fa fa-pinterest-p"></i>
                </a>
            <?php endif; ?>

            <?php if ( in_array( 'email', $socials ) ) : ?>
                <a href="mailto:?subject=<?php esc_attr_e( 'I wanted you to see this', 'deux' ) ?>&amp;body=<?php esc_attr_e( 'Check out this product', 'deux' ) . ' ' . rawurlencode( get_permalink() ) ?>" target="_blank" class="social-icon si-light si-rounded si-small si-email3">
                    <i class="fa fa-envelope"></i>
                    <i class="fa fa-envelope"></i>
                </a>
            <?php endif; ?>
        </div>

        <?php
    }
}