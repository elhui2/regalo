<?php
/**
 * Add more data for user
 */

/**
 * Add more contact method for user
 *
 * @param array $methods
 *
 * @return array
 */
function deux_addons_user_contact_methods( $methods ) {
	$methods['facebook']  = esc_html__( 'Facebook', 'deux' );
	$methods['twitter']   = esc_html__( 'Twitter', 'deux' );
	$methods['google']    = esc_html__( 'Google Plus', 'deux' );
	$methods['pinterest'] = esc_html__( 'Pinterest', 'deux' );
	$methods['instagram'] = esc_html__( 'Instagram', 'deux' );

	return $methods;
}

add_filter( 'user_contactmethods', 'deux_addons_user_contact_methods' );