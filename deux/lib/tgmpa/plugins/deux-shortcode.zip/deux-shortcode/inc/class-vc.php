<?php

/**
 * Class Deux_VC
 */
class Deux_VC {
	/**
	 * The single instance of the class.
	 *
	 * @var object
	 */
	protected static $_instance = null;

	/**
	 * Temporary cached terms variable
	 *
	 * @var array
	 */
	protected $terms = array();

	/**
	 * Main Instance.
	 * Ensures only one instance of WooCommerce is loaded or can be loaded.
	 *
	 * @return Deux_VC - Main instance.
	 */
	public static function init() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->modify_elements();
		$this->map_shortcodes();

		vc_set_as_theme();
		remove_action( 'admin_bar_menu', array( vc_frontend_editor(), 'adminBarEditLink' ), 1000 );
	}

	/**
	 * Modify VC element params
	 */
	public function modify_elements() {
		// Add new option to Custom Header element
		vc_add_param( 'vc_custom_heading', array(
			'heading'     => esc_html__( 'Separate URL', 'deux' ),
			'description' => esc_html__( 'Do not wrap heading text with link tag. Display URL separately', 'deux' ),
			'type'        => 'checkbox',
			'param_name'  => 'separate_link',
			'value'       => array( esc_html__( 'Yes', 'deux' ) => 'yes' ),
			'weight'      => 0,
		) );
		vc_add_param( 'vc_custom_heading', array(
			'heading'     => esc_html__( 'Link Arrow', 'deux' ),
			'description' => esc_html__( 'Add an arrow to the separated link when hover', 'deux' ),
			'type'        => 'checkbox',
			'param_name'  => 'link_arrow',
			'value'       => array( esc_html__( 'Yes', 'deux' ) => 'yes' ),
			'weight'      => 0,
			'dependency'  => array(
				'element' => 'separate_link',
				'value'   => 'yes',
			),
		) );
	}

	/**
	 * Register custom shortcodes within Visual Composer interface
	 *
	 * @see http://kb.wpbakery.com/index.php?title=Vc_map
	 */
	public function map_shortcodes() {

		vc_map( array(
			'name'                    => esc_html__( 'Container Slider', 'deux' ),
			'base'                    => 'deux_container_slider',
			'category'                => esc_html__( 'Deux', 'deux' ),
			'js_view'                 => 'VcColumnView',
			'content_element'         => true,
			'as_parent'               => array( 'only' => 'deux_testimonial,deux_banner1,deux_banner2,deux_banner3,deux_banner4 ' ),
			'params'                  => array(
				array(
					'heading'     => esc_html__( 'Columns', 'deux' ),
					'description' => esc_html__( 'Display products in how many columns', 'deux' ),
					'param_name'  => 'columns',
					'type'        => 'dropdown',
					'value'       => array(
						esc_html__( '1 Columns', 'deux' ) => 1,
						esc_html__( '2 Columns', 'deux' ) => 2,
						esc_html__( '3 Columns', 'deux' ) => 3,
						esc_html__( '4 Columns', 'deux' ) => 4,
						esc_html__( '5 Columns', 'deux' ) => 5,
						esc_html__( '6 Columns', 'deux' ) => 6,
					),
				),
				array(
					'heading'     => esc_html__( 'Auto Play', 'deux' ),
					'description' => esc_html__( 'Auto play speed in miliseconds. Enter "0" to disable auto play.', 'deux' ),
					'type'        => 'textfield',
					'param_name'  => 'autoplay',
					'value'       => 5000,
				),
				array(
					'heading'     => esc_html__( 'Loop', 'deux' ),
					'type'        => 'checkbox',
					'param_name'  => 'loop',
					'value'       => array( esc_html__( 'Yes', 'deux' ) => 'yes' ),
				),
				array(
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
					'param_name'  => 'el_class',
					'type'        => 'textfield',
				),
			),
		) );

		// Banner Grid 4
		vc_map( array(
			'name'                    => esc_html__( 'Banner Grid 4', 'deux' ),
			'description'             => esc_html__( 'Arrange 4 banners per row with unusual structure.', 'deux' ),
			'base'                    => 'deux_banner_grid_4',
			'category'                => esc_html__( 'Deux', 'deux' ),
			'js_view'                 => 'VcColumnView',
			'content_element'         => true,
			'show_settings_on_create' => false,
			'as_parent'               => array( 'only' => 'deux_banner1,deux_banner2,deux_banner3,deux_banner4' ),
			'params'                  => array(
				array(
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
					'param_name'  => 'el_class',
					'type'        => 'textfield',
				),
				// array(
				// 	'heading'     => esc_html__( 'Gap', 'deux' ),
				// 	'description' => esc_html__( 'Insert gap between banner', 'deux' ),
				// 	'type'        => 'checkbox',
				// 	'param_name'  => 'gap',
				// ),
			),
		) );
 
		// Banner Grid 5
		vc_map( array(
			'name'                    => esc_html__( 'Banner Grid 5', 'deux' ),
			'description'             => esc_html__( 'Arrange 5 banners in 3 columns.', 'deux' ),
			'base'                    => 'deux_banner_grid_5',
			'category'                => esc_html__( 'Deux', 'deux' ),
			'js_view'                 => 'VcColumnView',
			'content_element'         => true,
			'show_settings_on_create' => false,
			'as_parent'               => array( 'only' => 'deux_banner1,deux_banner2,deux_banner3,deux_banner4' ),
			'params'                  => array(
				array(
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
					'param_name'  => 'el_class',
					'type'        => 'textfield',
				),
				// array(
				// 	'heading'     => esc_html__( 'Gap', 'deux' ),
				// 	'description' => esc_html__( 'Insert gap between banner', 'deux' ),
				// 	'type'        => 'checkbox',
				// 	'param_name'  => 'gap',
				// ),
			),
		) );

		// Banner Grid 6
		vc_map( array(
			'name'                    => esc_html__( 'Banner Grid 6', 'deux' ),
			'description'             => esc_html__( 'Arrange 6 banners in 4 columns.', 'deux' ),
			'base'                    => 'deux_banner_grid_6',
			'category'                => esc_html__( 'Deux', 'deux' ),
			'js_view'                 => 'VcColumnView',
			'content_element'         => true,
			'show_settings_on_create' => false,
			'as_parent'               => array( 'only' => 'deux_banner1,deux_banner2,deux_banner3,deux_banner4' ),
			'params'                  => array(
				array(
					'heading'     => esc_html__( 'Reverse Order', 'deux' ),
					'description' => esc_html__( 'Reverse the order of banners inside this grid', 'deux' ),
					'param_name'  => 'reverse',
					'type'        => 'checkbox',
					'value'       => array( esc_html__( 'Yes', 'deux' ) => 'yes' ),
				),
				// array(
				// 	'heading'     => esc_html__( 'Gap', 'deux' ),
				// 	'description' => esc_html__( 'Insert gap between banner', 'deux' ),
				// 	'type'        => 'checkbox',
				// 	'param_name'  => 'gap',
				// ),
				array(
					'heading'     => esc_html__( 'Extra class name', 'deux' ),
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'deux' ),
					'param_name'  => 'el_class',
					'type'        => 'textfield',
				),
			),
		) );
	}
	 
}

