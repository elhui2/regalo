<?php add_action( 'vc_load_default_templates_action', 'deux_template_home_decor_ver_1' ); // Hook in
 
function deux_template_home_decor_ver_1() {
    $data               = array(); // Create new array
    $data['name']       = __( 'Home Decor v1', 'deux' ); // Assign name for your custom template
    $data['weight']     = 0; // Weight of your template in the template list
    $data['custom_class'] = 'custom_template_for_vc_custom_template'; // CSS class name
    $data['content']    = <<<CONTENT
      [vc_row][vc_column][vc_row_inner][vc_column_inner offset="vc_hidden-sm vc_hidden-xs"][masterslider_pb alias="ms-1"][/vc_column_inner][/vc_row_inner][vc_row_inner][vc_column_inner offset="vc_hidden-lg vc_hidden-md" css=".vc_custom_1522824377063{margin-top: 40px !important;}"][masterslider_pb alias="ms-1-1"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row css=".vc_custom_1511477948560{margin-top: 100px !important;}"][vc_column width="1/2"][deux_banner1 color="#ffffff" image_size="full" title="Risom Lounge" subtitle="by Knoll" link="url:http%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fhomedecor%2Fproduct%2Frisom-lounge-chair%2F|title:%C2%A3%20898.00|target:%20_blank|" image="1137"][vc_row_inner][vc_column_inner offset="vc_hidden-lg vc_hidden-md vc_hidden-sm"][vc_empty_space height="30px"][/vc_column_inner][/vc_row_inner][/vc_column][vc_column width="1/2"][deux_banner1 color="#ffffff" image_size="full" title="Organic Chair" subtitle="by Vitra" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fhomedecor%2Fproduct%2Forganic-chair%2F|title:%C2%A3%201%2C400.00|target:%20_blank|" image="1139"][/vc_column][/vc_row][vc_row full_width="stretch_row_content" gap="15" css=".vc_custom_1518272251674{margin-top: 100px !important;}"][vc_column][deux_product_grid per_page="10" columns="5"][/vc_column][/vc_row][vc_row css=".vc_custom_1511843096109{margin-top: 100px !important;}"][vc_column width="1/2" css=".vc_custom_1515358997200{margin-bottom: 30px !important;}"][deux_banner4 color="#ffffff" image="1140" label="hot" title="Form Chair" subtitle="by Normann Copenhagen" link="url:http%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fhomedecor%2Fproduct%2Fgrain-pendant-lamp%2F|title:lamp|target:%20_blank|"][/vc_column][vc_column width="1/2" css=".vc_custom_1515359034670{margin-bottom: 30px !important;}"][deux_banner4 scheme="light" color="#ffffff" image="1138" label="30% off" title="Form Table" subtitle="by Normann Copenhagen" link="url:http%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fhomedecor%2Fproduct%2Fmino%2F|title:mino|target:%20_blank|"][/vc_column][/vc_row][vc_row full_width="stretch_row" css=".vc_custom_1518270785376{margin-top: 20px !important;padding-top: 50px !important;padding-bottom: 50px !important;background-color: #f9f9f9 !important;}"][vc_column][deux_post_image category="architecture"][/vc_column][/vc_row]
CONTENT;
  
    vc_add_default_templates( $data );
}


add_action( 'vc_load_default_templates_action','deux_template_home_decor_ver_2' ); // Hook in
 
function deux_template_home_decor_ver_2() {
    $data               = array(); // Create new array
    $data['name']       = __( 'Home Decor v2', 'deux' ); // Assign name for your custom template
    $data['weight']     = 0; // Weight of your template in the template list
    $data['custom_class'] = 'custom_template_for_vc_custom_template'; // CSS class name
    $data['content']    = <<<CONTENT
      [vc_row][vc_column][vc_row_inner][vc_column_inner offset="vc_hidden-sm vc_hidden-xs"][masterslider_pb alias="ms-2"][/vc_column_inner][/vc_row_inner][vc_row_inner][vc_column_inner offset="vc_hidden-lg vc_hidden-md"][masterslider_pb alias="ms-2-1"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row css=".vc_custom_1519626498815{margin-top: 100px !important;}"][vc_column width="1/2"][deux_banner3 image_size="full" text_align="right" color="#ff7a5f" image="1318" title="Organic Chair" sub="by Vitra" vtitle="Designed by Charles Eames" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fhomedecor%2Fproduct%2Forganic-chair%2F|title:%C2%A31%2C400.00|target:%20_blank|"][vc_row_inner][vc_column_inner][vc_empty_space height="100px"][/vc_column_inner][/vc_row_inner][deux_banner3 image_size="full" text_align="left" text_valign="right" color="#333333" image="1321" title="30 Degree Lamp" sub="by Wrong.London" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fhomedecor%2Fproduct%2F30-degree-lamp%2F|title:%C2%A3105.00|target:%20_blank|"][vc_row_inner css=".vc_custom_1522826337580{margin-top: 0px !important;margin-bottom: 0px !important;}"][vc_column_inner offset="vc_hidden-xs"][vc_empty_space height="100px"][vc_custom_heading text="VIEW ALL PRODUCT" font_container="tag:h2|font_size:16px|text_align:left" use_theme_fonts="yes" link="url:%23https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fhomedecor%2Fshop%2F|title:product|target:%20_blank|" el_class="letter-spacing"][vc_separator color="custom" align="align_left" border_width="2" el_width="10" accent_color="#ff7a5f" css=".vc_custom_1519621192459{margin-top: -65px !important;}"][/vc_column_inner][/vc_row_inner][/vc_column][vc_column width="1/2"][vc_row_inner][vc_column_inner offset="vc_hidden-xs"][vc_empty_space height="200px"][/vc_column_inner][/vc_row_inner][deux_banner3 image_size="full" text_valign="right" color="#333333" image="1320" title="Kay Bojesen Dog Tim" sub="by Rosendahl" vtitle="Accessories" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fhomedecor%2Fproduct%2Fkay-bojesen-dog-tim%2F|title:%C2%A335.00|target:%20_blank|"][vc_row_inner][vc_column_inner][vc_empty_space height="50px"][/vc_column_inner][/vc_row_inner][deux_banner3 image_size="full" text_align="left" text_valign="right" color="#ff7a5f" image="1319" title="Nara Coat Stand" sub="by Fredericia" vtitle="Accessories" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fhomedecor%2Fproduct%2Fnara-coat-stand%2F|title:%C2%A3265.00|target:%20_blank|"][/vc_column][/vc_row][vc_row full_width="stretch_row" css=".vc_custom_1519732572527{margin-top: 100px !important;background-color: #f6f6f6 !important;}"][vc_column offset="vc_hidden-xs"][vc_row_inner content_placement="middle"][vc_column_inner width="1/2"][vc_custom_heading text="DEUX STORE" font_container="tag:h2|font_size:10px|text_align:left" use_theme_fonts="yes" link="url:%23|title:product|target:%20_blank|" el_class="letter-spacing" css=".vc_custom_1519731207425{margin-bottom: 10px !important;}"][vc_custom_heading text="Deal of The Month" font_container="tag:h2|font_size:50px|text_align:left|color:%23ff7a5f" use_theme_fonts="yes" link="url:%23|title:product|target:%20_blank|" css=".vc_custom_1519731322309{margin-bottom: 30px !important;}"][vc_custom_heading text="£1,675.00" font_container="tag:h2|font_size:30px|text_align:left" use_theme_fonts="yes" link="url:%23|title:product|target:%20_blank|" css=".vc_custom_1519732411641{margin-bottom: 10px !important;}"][vc_custom_heading text="Outline Chair" font_container="tag:h2|font_size:20px|text_align:left" use_theme_fonts="yes" link="url:%23|title:product|target:%20_blank|"][deux_countdown date="2018/07/01"][vc_btn title="VIEW PRODUCT" style="outline-custom" outline_custom_color="#ff7a5f" outline_custom_hover_background="#ff7a5f" outline_custom_hover_text="#ffffff" shape="square" css=".vc_custom_1519732462100{margin-top: 30px !important;}" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fhomedecor%2Fproduct%2Foutline-chair%2F|title:outline|target:%20_blank|"][/vc_column_inner][vc_column_inner width="1/2"][vc_images_carousel images="604,607" img_size="large" onclick="link_no" autoplay="yes" hide_pagination_control="yes" wrap="yes"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row css=".vc_custom_1518271449431{padding-top: 100px !important;}"][vc_column][vc_custom_heading text="New Arrival " font_container="tag:h3|font_size:30|text_align:center|color:%231b1b1b" use_theme_fonts="yes" css=".vc_custom_1511844910477{margin-bottom: 30px !important;}"][deux_product_tabs per_page="8" columns="4" category="accessories, seating, lighting"][/vc_column][/vc_row][vc_row css=".vc_custom_1511844752220{padding-top: 100px !important;}"][vc_column][vc_custom_heading text="Journal This Week" font_container="tag:h3|font_size:30|text_align:center|color:%231b1b1b" use_theme_fonts="yes" css=".vc_custom_1513682198696{margin-bottom: 30px !important;}"][deux_post_grid per_page="3" columns="3" category="design"][/vc_column][/vc_row]
CONTENT;
  
    vc_add_default_templates( $data );
}


add_action( 'vc_load_default_templates_action','deux_template_kitchenware_ver_1' ); // Hook in
 
function deux_template_kitchenware_ver_1() {
    $data               = array(); // Create new array
    $data['name']       = __( 'Home Kitchenware v1', 'deux' ); // Assign name for your custom template
    $data['weight']     = 0; // Weight of your template in the template list
    $data['custom_class'] = 'custom_template_for_vc_custom_template'; // CSS class name
    $data['content']    = <<<CONTENT
      [vc_row][vc_column][masterslider_pb alias="ms-1"][/vc_column][/vc_row][vc_row css=".vc_custom_1520519494332{margin-top: 100px !important;}"][vc_column][vc_custom_heading text="Featured Product" font_container="tag:h2|font_size:30|text_align:center|color:%231b1b1b" use_theme_fonts="yes" css=".vc_custom_1520520008207{margin-bottom: 0px !important;}"][vc_column_text css=".vc_custom_1520520159246{margin-top: 20px !important;}"]

Get featured product in high quality, fast deliver and quick response from deux store

[/vc_column_text][vc_row_inner][vc_column_inner width="1/2"][deux_banner3 image_size="full" color="#aaca97" image="223" title="Saikai " sub="Kitchen Knife" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fkitchens%2Fproduct%2Fsaikai-kitchen-knife%2F|title:%C2%A3%20330.00||"][/vc_column_inner][vc_column_inner width="1/2"][deux_banner3 image_size="full" text_valign="right" color="#aaca97" image="225" title="Hasami " sub="Porcelain Bottle" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fkitchens%2Fproduct%2Fhasami-porcelain-bottle%2F|title:%C2%A3%2048.00||"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row full_width="stretch_row_content" css=".vc_custom_1520521093555{margin-top: 100px !important;padding-right: 50px !important;padding-left: 50px !important;}"][vc_column width="1/3"][vc_cta h2="Free Shipping Worldwide" h2_font_container="font_size:30|color:%231b1b1b|line_height:1" h2_use_theme_fonts="yes" txt_align="center" style="outline" color="grey" add_icon="top" i_type="linecons" i_icon_linecons="vc_li vc_li-world" i_color="grey" i_background_style="boxed" i_background_color="white" i_size="lg" use_custom_fonts_h2="true" i_on_border="true"]

Shipping prices for any form of delivery and order’s cost is constant

[/vc_cta][/vc_column][vc_column width="1/3"][vc_cta h2="Returns For 30 Days" h2_font_container="font_size:30|color:%231b1b1b|line_height:1" h2_use_theme_fonts="yes" txt_align="center" style="outline" color="grey" add_icon="top" i_type="linecons" i_icon_linecons="vc_li vc_li-mail" i_color="grey" i_background_style="boxed" i_background_color="white" i_size="lg" use_custom_fonts_h2="true" i_on_border="true"]

Any goods, can be returned during 30 days since purchase date.

[/vc_cta][/vc_column][vc_column width="1/3"][vc_cta h2="+12 123 456 234" h2_font_container="font_size:30|color:%231b1b1b|line_height:1" h2_use_theme_fonts="yes" txt_align="center" style="outline" color="grey" add_icon="top" i_type="linecons" i_icon_linecons="vc_li vc_li-phone" i_color="grey" i_background_style="boxed" i_background_color="white" i_size="lg" use_custom_fonts_h2="true" i_on_border="true"]

Toll-free hotline.
7 days a week from 10.00 a.m. to 6.00 p.m.

[/vc_cta][/vc_column][/vc_row][vc_row css=".vc_custom_1520521163287{margin-top: 100px !important;}"][vc_column][vc_custom_heading text="Trending Product" font_container="tag:h2|font_size:30|text_align:center|color:%231b1b1b" use_theme_fonts="yes" css=".vc_custom_1520521292176{margin-bottom: 30px !important;}"][deux_product_carousel number="15" columns="4" autoplay="5000" loop="yes"][/vc_column][/vc_row][vc_row css=".vc_custom_1520521163287{margin-top: 100px !important;}"][vc_column][vc_custom_heading text="News From Us" font_container="tag:h2|font_size:30|text_align:center|color:%231b1b1b" use_theme_fonts="yes" css=".vc_custom_1520521702018{margin-bottom: 30px !important;}"][deux_post_image][/vc_column][/vc_row]
CONTENT;
  
    vc_add_default_templates( $data );
}


add_action( 'vc_load_default_templates_action','deux_template_kitchenware_ver_2' ); // Hook in
 
function deux_template_kitchenware_ver_2() {
    $data               = array(); // Create new array
    $data['name']       = __( 'Home Kitchenware v2', 'deux' ); // Assign name for your custom template
    $data['weight']     = 0; // Weight of your template in the template list
    $data['custom_class'] = 'custom_template_for_vc_custom_template'; // CSS class name
    $data['content']    = <<<CONTENT
      [vc_row][vc_column][masterslider_pb alias="ms-1"][/vc_column][/vc_row][vc_row css=".vc_custom_1520519494332{margin-top: 100px !important;}"][vc_column][vc_custom_heading text="Featured Product" font_container="tag:h2|font_size:30|text_align:center|color:%231b1b1b" use_theme_fonts="yes" css=".vc_custom_1520522862108{margin-bottom: 30px !important;}"][deux_banner_grid_5][deux_banner1 color="#000000" image_size="full" title="Hasami Mug" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fkitchens%2Fproduct%2Fhasami-porcelain-mug%2F|title:%C2%A327.50|target:%20_blank|" image="126"][deux_banner1 color="#000000" image_size="full" title="Emerald Napkin " link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fkitchens%2Fproduct%2Fnapkin-in-emerald%2F||target:%20_blank|" image="116"][deux_banner1 color="#000000" image_size="full" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fkitchens%2Fproduct%2Fnambu-tekki%2F|title:%C2%A399.00|target:%20_blank|" image="103"][deux_banner1 color="#ffffff" image_size="full" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fkitchens%2Fproduct%2Fnoda-horo%2F|title:%C2%A3125.00|target:%20_blank|" image="114"][deux_banner1 color="#000000" image_size="full" title="Hasami Plate" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fkitchens%2Fproduct%2Fhasami-porcelain%2F|title:%C2%A396.00|target:%20_blank|" image="107"][/deux_banner_grid_5][/vc_column][/vc_row][vc_row css=".vc_custom_1520521163287{margin-top: 100px !important;}"][vc_column][vc_custom_heading text="Trending Product" font_container="tag:h2|font_size:30|text_align:center|color:%231b1b1b" use_theme_fonts="yes" css=".vc_custom_1520521292176{margin-bottom: 30px !important;}"][deux_product_grid per_page="8" columns="4" load_more="yes"][/vc_column][/vc_row][vc_row css=".vc_custom_1520521163287{margin-top: 100px !important;}"][vc_column][vc_custom_heading text="News From Us" font_container="tag:h2|font_size:30|text_align:center|color:%231b1b1b" use_theme_fonts="yes" css=".vc_custom_1520521702018{margin-bottom: 30px !important;}"][deux_post_grid per_page="3" columns="3"][/vc_column][/vc_row]
CONTENT;
  
    vc_add_default_templates( $data );
}


add_action( 'vc_load_default_templates_action','deux_template_lavatory_ver_1' ); // Hook in
 
function deux_template_lavatory_ver_1() {
    $data               = array(); // Create new array
    $data['name']       = __( 'Home Lavatory v1', 'deux' ); // Assign name for your custom template
    $data['weight']     = 0; // Weight of your template in the template list
    $data['custom_class'] = 'custom_template_for_vc_custom_template'; // CSS class name
    $data['content']    = <<<CONTENT
      [vc_row][vc_column][masterslider_pb alias="ms-1"][/vc_column][/vc_row][vc_row css=".vc_custom_1520506005882{margin-top: 100px !important;}"][vc_column][deux_product_tabs per_page="10" columns="5" category="miscellaneous, towel"][/vc_column][/vc_row][vc_row css=".vc_custom_1520505997914{margin-top: 100px !important;}"][vc_column][deux_product_slider2 ids=""][/vc_column][/vc_row][vc_row full_width="stretch_row_content" css=".vc_custom_1520506496487{margin-top: 100px !important;padding-top: 50px !important;padding-right: 50px !important;padding-bottom: 50px !important;padding-left: 50px !important;}"][vc_column width="1/3"][vc_cta h2="Free Shipping Worldwide" h2_font_container="font_size:25|color:%231b1b1b|line_height:1" h2_use_theme_fonts="yes" txt_align="center" shape="square" style="outline" color="grey" add_icon="top" i_type="linecons" i_icon_linecons="vc_li vc_li-world" i_color="grey" i_background_style="boxed" i_background_color="white" i_size="lg" use_custom_fonts_h2="true" i_on_border="true"]

Shipping prices for any form of delivery and order’s cost is constant

[/vc_cta][/vc_column][vc_column width="1/3"][vc_cta h2="Returns For 30 Days" h2_font_container="font_size:25|color:%231b1b1b|line_height:1" h2_use_theme_fonts="yes" txt_align="center" shape="square" style="outline" color="grey" add_icon="top" i_type="linecons" i_icon_linecons="vc_li vc_li-mail" i_color="grey" i_background_style="boxed" i_background_color="white" i_size="lg" use_custom_fonts_h2="true" i_on_border="true"]

Any goods, can be returned during 30 days since purchase date.

[/vc_cta][/vc_column][vc_column width="1/3"][vc_cta h2="+12 123 456 234" h2_font_container="font_size:25|color:%231b1b1b|line_height:1" h2_use_theme_fonts="yes" txt_align="center" shape="square" style="outline" color="grey" add_icon="top" i_type="linecons" i_icon_linecons="vc_li vc_li-phone" i_color="grey" i_background_style="boxed" i_background_color="white" i_size="lg" use_custom_fonts_h2="true" i_on_border="true"]

Toll-free hotline.
7 days a week from 10.00 a.m. to 6.00 p.m.

[/vc_cta][/vc_column][/vc_row][vc_row css=".vc_custom_1515412487303{margin-top: 100px !important;}"][vc_column][vc_custom_heading text="Editor's News" font_container="tag:h3|font_size:25|text_align:center" use_theme_fonts="yes" css=".vc_custom_1515412521322{margin-bottom: 30px !important;}"][deux_post_image][/vc_column][/vc_row][vc_row][vc_column][vc_column_text][/vc_column_text][/vc_column][/vc_row]
CONTENT;
  
    vc_add_default_templates( $data );
}

add_action( 'vc_load_default_templates_action','deux_template_lavatory_ver_2' ); // Hook in
 
function deux_template_lavatory_ver_2() {
    $data               = array(); // Create new array
    $data['name']       = __( 'Home Lavatory v2', 'deux' ); // Assign name for your custom template
    $data['weight']     = 0; // Weight of your template in the template list
    $data['custom_class'] = 'custom_template_for_vc_custom_template'; // CSS class name
    $data['content']    = <<<CONTENT
      [vc_row][vc_column][masterslider_pb alias="ms-1"][/vc_column][/vc_row][vc_row css=".vc_custom_1515410934080{margin-top: 100px !important;}"][vc_column][vc_custom_heading text="Editor's Choices" font_container="tag:h3|font_size:25|text_align:left" use_theme_fonts="yes" css=".vc_custom_1515412703236{margin-bottom: 30px !important;}"][vc_separator color="custom" align="align_left" border_width="2" el_width="10" accent_color="#6ea2d5" css=".vc_custom_1520509193680{margin-top: -25px !important;margin-bottom: 30px !important;}"][deux_banner_grid_6][deux_banner1 color="#000000" image_size="full" image="173" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fbath%2Fproduct%2Faesop-wanderer-hair-care-kit%2F|title:Aesop%20Wanderer||"][deux_banner1 color="#000000" image_size="full" image="155" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fbath%2Fproduct%2Fhawkins-new-york%2F|title:Hawkins%20New%20York||"][deux_banner1 color="#000000" image_size="full" image="160" title=" " link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fbath%2Fproduct%2Fshapes-towel-in-blue%2F|title:%20||"][deux_banner1 color="#000000" image_size="full" image="162" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fbath%2Fproduct%2Fherringbone-cotton-towel%2F|title:58.00||"][deux_banner1 color="#ffffff" image_size="full" image="167" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fbath%2Fproduct%2Fwork-towel%2F|title:75.00||"][deux_banner1 color="#000000" image="165" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Fbath%2Fproduct%2Fhawkins-new-york%2F|title:16.00||"][/deux_banner_grid_6][/vc_column][/vc_row][vc_row css=".vc_custom_1515412054025{margin-top: 100px !important;}"][vc_column][vc_custom_heading text="Explore Our Product" font_container="tag:h3|font_size:25|text_align:left" use_theme_fonts="yes" css=".vc_custom_1515412727318{margin-bottom: 30px !important;}"][vc_separator color="custom" align="align_left" border_width="2" el_width="10" accent_color="#6ea2d5" css=".vc_custom_1520509203425{margin-top: -25px !important;margin-bottom: 30px !important;}"][deux_product_grid per_page="8" columns="4" load_more="yes"][/vc_column][/vc_row][vc_row css=".vc_custom_1515412054025{margin-top: 100px !important;}"][vc_column][vc_custom_heading text="Latest Product" font_container="tag:h3|font_size:25|text_align:left" use_theme_fonts="yes" css=".vc_custom_1515412746658{margin-bottom: 30px !important;}"][vc_separator color="custom" align="align_left" border_width="2" el_width="10" accent_color="#6ea2d5" css=".vc_custom_1520509259846{margin-top: -25px !important;margin-bottom: 30px !important;}"][deux_product_carousel number="8" columns="4" autoplay="5000"][/vc_column][/vc_row][vc_row css=".vc_custom_1515412054025{margin-top: 100px !important;}"][vc_column][vc_custom_heading text="Tips & Trick" font_container="tag:h3|font_size:25|text_align:left" use_theme_fonts="yes" css=".vc_custom_1515412768242{margin-bottom: 30px !important;}"][vc_separator color="custom" align="align_left" border_width="2" el_width="10" accent_color="#6ea2d5" css=".vc_custom_1520509212510{margin-top: -25px !important;margin-bottom: 30px !important;}"][deux_post_grid per_page="3" columns="3"][/vc_column][/vc_row]
CONTENT;
  
    vc_add_default_templates( $data );
}


add_action( 'vc_load_default_templates_action','deux_template_house_wave_ver_1' ); // Hook in
 
function deux_template_house_wave_ver_1() {
    $data               = array(); // Create new array
    $data['name']       = __( 'House Wave v1', 'deux' ); // Assign name for your custom template
    $data['weight']     = 0; // Weight of your template in the template list
    $data['custom_class'] = 'custom_template_for_vc_custom_template'; // CSS class name
    $data['content']    = <<<CONTENT
      [vc_row][vc_column][masterslider_pb alias="ms-3-1-1-1"][/vc_column][/vc_row][vc_row css=".vc_custom_1520782446230{margin-top: 100px !important;padding-right: 0px !important;padding-left: 0px !important;}"][vc_column][deux_banner_grid_4][deux_banner3 image_size="full" text_align="left" text_valign="right" color="#3267ad" image="125" title="B&O" sub="Play S3" vtitle="From B&O Play" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Faudio-tech%2Fproduct%2Fbo-play-s3%2F|title:%C2%A3299.00|target:%20_blank|"][deux_banner3 image_size="full" text_valign="right" color="#d6d6d6" image="99" title="Aiaiai" sub="TMA-2" vtitle="Headset" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Faudio-tech%2Fproduct%2Faiaiai-tma-2%2F|title:%C2%A3225.00|target:%20_blank|"][deux_banner3 image_size="full" color="#dd3333" image="97" title="Sennheiser" sub="Urbanite" vtitle="Sale 40%" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Faudio-tech%2Fproduct%2Fsennheiser-urbanite%2F|title:%C2%A3140.00|target:%20_blank|"][deux_banner3 image_size="full" text_align="right" color="#d6d6d6" image="121" title="B&O" sub="Play A2" vtitle="Speaker" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Faudio-tech%2Fproduct%2Fbo-play-a2%2F|title:%C2%A3399.00|target:%20_blank|"][/deux_banner_grid_4][/vc_column][/vc_row][vc_row full_width="stretch_row_content" css=".vc_custom_1520783135059{margin-top: 100px !important;padding-right: 0px !important;padding-left: 0px !important;}"][vc_column][deux_product_grid per_page="10" columns="5"][/vc_column][/vc_row][vc_row css=".vc_custom_1520780412612{margin-top: 100px !important;padding-right: 0px !important;padding-left: 0px !important;}"][vc_column][deux_product_slider2 ids="141, 147, 150, 142"][/vc_column][/vc_row][vc_row css=".vc_custom_1520781506358{margin-top: 150px !important;}"][vc_column][deux_post_image][/vc_column][/vc_row]
CONTENT;
  
    vc_add_default_templates( $data );
}

add_action( 'vc_load_default_templates_action','deux_template_house_wave_ver_2' ); // Hook in
function deux_template_house_wave_ver_2() {
    $data               = array(); // Create new array
    $data['name']       = __( 'House Wave v1', 'deux' ); // Assign name for your custom template
    $data['weight']     = 0; // Weight of your template in the template list
    $data['custom_class'] = 'custom_template_for_vc_custom_template'; // CSS class name
    $data['content']    = <<<CONTENT
     [vc_row][vc_column][masterslider_pb alias="ms-3-1-1-1"][/vc_column][/vc_row][vc_row css=".vc_custom_1520506005882{margin-top: 100px !important;}"][vc_column][deux_product_tabs per_page="10" columns="5"][/vc_column][/vc_row][vc_row css=".vc_custom_1520505997914{margin-top: 100px !important;}"][vc_column][deux_product_slider2 ids="153, 150, 142, 141"][/vc_column][/vc_row][vc_row full_width="stretch_row_content" css=".vc_custom_1520506496487{margin-top: 100px !important;padding-top: 50px !important;padding-right: 50px !important;padding-bottom: 50px !important;padding-left: 50px !important;}"][vc_column width="1/3"][vc_cta h2="Free Shipping Worldwide" h2_font_container="font_size:25|color:%231b1b1b|line_height:1" h2_use_theme_fonts="yes" txt_align="center" shape="square" style="outline" color="grey" add_icon="top" i_type="linecons" i_icon_linecons="vc_li vc_li-world" i_color="grey" i_background_style="boxed" i_background_color="white" i_size="lg" use_custom_fonts_h2="true" i_on_border="true"]

Shipping prices for any form of delivery and order’s cost is constant

[/vc_cta][/vc_column][vc_column width="1/3"][vc_cta h2="Returns For 30 Days" h2_font_container="font_size:25|color:%231b1b1b|line_height:1" h2_use_theme_fonts="yes" txt_align="center" shape="square" style="outline" color="grey" add_icon="top" i_type="linecons" i_icon_linecons="vc_li vc_li-mail" i_color="grey" i_background_style="boxed" i_background_color="white" i_size="lg" use_custom_fonts_h2="true" i_on_border="true"]

Any goods, can be returned during 30 days since purchase date.

[/vc_cta][/vc_column][vc_column width="1/3"][vc_cta h2="+12 123 456 234" h2_font_container="font_size:25|color:%231b1b1b|line_height:1" h2_use_theme_fonts="yes" txt_align="center" shape="square" style="outline" color="grey" add_icon="top" i_type="linecons" i_icon_linecons="vc_li vc_li-phone" i_color="grey" i_background_style="boxed" i_background_color="white" i_size="lg" use_custom_fonts_h2="true" i_on_border="true"]

Toll-free hotline.
7 days a week from 10.00 a.m. to 6.00 p.m.

[/vc_cta][/vc_column][/vc_row][vc_row css=".vc_custom_1515412487303{margin-top: 100px !important;}"][vc_column][vc_custom_heading text="Editor's News" font_container="tag:h3|font_size:25|text_align:center" use_theme_fonts="yes" css=".vc_custom_1515412521322{margin-bottom: 30px !important;}"][deux_post_image][/vc_column][/vc_row]
CONTENT;
  
    vc_add_default_templates( $data );
}

add_action( 'vc_load_default_templates_action','deux_template_working_space_ver_1' ); // Hook in
 
function deux_template_working_space_ver_1() {
    $data               = array(); // Create new array
    $data['name']       = __( 'Working Space v1', 'deux' ); // Assign name for your custom template
    $data['weight']     = 0; // Weight of your template in the template list
    $data['custom_class'] = 'custom_template_for_vc_custom_template'; // CSS class name
    $data['content']    = <<<CONTENT
      [vc_row][vc_column][masterslider_pb alias="ms-1"][/vc_column][/vc_row][vc_row css=".vc_custom_1520782446230{margin-top: 100px !important;padding-right: 0px !important;padding-left: 0px !important;}"][vc_column][deux_banner_grid_4][deux_banner3 image_size="full" text_align="left" text_valign="right" color="#3267ad" image="115" title="Delfonics" sub="Paper Holder" vtitle="Delfonics Paper " link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Foffice%2Fproduct%2Fappointed-document-folder%2F|title:%C2%A330.00|target:%20_blank|"][deux_banner3 image_size="full" text_valign="right" color="#d6d6d6" image="133" title="Appointed" sub="Document Folder" vtitle="Accessories" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Foffice%2Fproduct%2Fdelfonics-paper-holder%2F|title:%C2%A38.00|target:%20_blank|"][deux_banner3 image_size="full" color="#dd3333" image="113" title="Memo " sub="Block Small" vtitle="Sale 40%" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Foffice%2Fproduct%2Fmemo-block-small%2F|title:%C2%A318.00|target:%20_blank|"][deux_banner3 image_size="full" text_align="right" color="#d6d6d6" image="122" title="Appointed " sub="Notepad" vtitle="Notepad" link="url:https%3A%2F%2Fqedqod.com%2Fdemo%2Fdeux%2Foffice%2Fproduct%2Fappointed-notepad%2F|title:%C2%A312.00|target:%20_blank|"][/deux_banner_grid_4][/vc_column][/vc_row][vc_row full_width="stretch_row_content" css=".vc_custom_1520783135059{margin-top: 100px !important;padding-right: 0px !important;padding-left: 0px !important;}"][vc_column][deux_product_grid per_page="10" columns="5"][/vc_column][/vc_row][vc_row css=".vc_custom_1520780412612{margin-top: 100px !important;padding-right: 0px !important;padding-left: 0px !important;}"][vc_column][deux_product_carousel number="8" columns="4" autoplay="5000"][/vc_column][/vc_row][vc_row css=".vc_custom_1520781506358{margin-top: 150px !important;}"][vc_column][deux_post_image][/vc_column][/vc_row]
CONTENT;
  
    vc_add_default_templates( $data );
}

add_action( 'vc_load_default_templates_action','deux_template_working_space_ver_2' ); // Hook in
function deux_template_working_space_ver_2() {
    $data               = array(); // Create new array
    $data['name']       = __( 'Working Space v2', 'deux' ); // Assign name for your custom template
    $data['weight']     = 0; // Weight of your template in the template list
    $data['custom_class'] = 'custom_template_for_vc_custom_template'; // CSS class name
    $data['content']    = <<<CONTENT
     [vc_row][vc_column][masterslider_pb alias="ms-1"][/vc_column][/vc_row][vc_row css=".vc_custom_1520778041569{margin-top: 100px !important;}"][vc_column][vc_row_inner][vc_column_inner width="1/3"][vc_separator color="custom" align="align_left" border_width="2" el_width="10" accent_color="#3267ad" css=".vc_custom_1520779472466{margin-left: 85px !important;}"][vc_cta h2="Free Shiping" h2_font_container="font_size:24|color:%231b1b1b" h2_google_fonts="font_family:Montserrat%3Aregular%2C700|font_style:400%20regular%3A400%3Anormal" h4="All Order Over $30" h4_font_container="font_size:12|color:%23dbdbdb" h4_google_fonts="font_family:Montserrat%3Aregular%2C700|font_style:400%20regular%3A400%3Anormal" style="outline" color="white" add_icon="left" i_type="linecons" i_icon_linecons="vc_li vc_li-world" i_color="custom" i_size="lg" use_custom_fonts_h2="true" use_custom_fonts_h4="true" i_on_border="true" i_custom_color="#3267ad" h2_el_class="nomargin" h4_el_class="letter-spacing " css=".vc_custom_1520779762620{margin-top: -10px !important;}"]Shipping prices for any form of delivery and order’s cost is constant[/vc_cta][/vc_column_inner][vc_column_inner width="1/3"][vc_separator color="custom" align="align_left" border_width="2" el_width="10" accent_color="#3267ad" css=".vc_custom_1520779472466{margin-left: 85px !important;}"][vc_cta h2="Returns Items" h2_font_container="font_size:24|color:%231b1b1b" h2_google_fonts="font_family:Montserrat%3Aregular%2C700|font_style:400%20regular%3A400%3Anormal" h4="For All Items" h4_font_container="font_size:12|color:%23dbdbdb" h4_google_fonts="font_family:Montserrat%3Aregular%2C700|font_style:400%20regular%3A400%3Anormal" style="outline" color="white" add_icon="left" i_type="linecons" i_icon_linecons="vc_li vc_li-world" i_color="custom" i_size="lg" use_custom_fonts_h2="true" use_custom_fonts_h4="true" i_on_border="true" i_custom_color="#3267ad" h2_el_class="nomargin" h4_el_class="letter-spacing " css=".vc_custom_1520779773292{margin-top: -10px !important;}"]Any goods, can be returned during 30 days since purchase date.[/vc_cta][/vc_column_inner][vc_column_inner width="1/3"][vc_separator color="custom" align="align_left" border_width="2" el_width="10" accent_color="#3267ad" css=".vc_custom_1520779472466{margin-left: 85px !important;}"][vc_cta h2=" +12 123 456 234" h2_font_container="font_size:24|color:%231b1b1b" h2_google_fonts="font_family:Montserrat%3Aregular%2C700|font_style:400%20regular%3A400%3Anormal" h4="24/7 Support" h4_font_container="font_size:12|color:%23dbdbdb" h4_google_fonts="font_family:Montserrat%3Aregular%2C700|font_style:400%20regular%3A400%3Anormal" style="outline" color="white" add_icon="left" i_type="linecons" i_icon_linecons="vc_li vc_li-phone" i_color="custom" i_size="lg" use_custom_fonts_h2="true" use_custom_fonts_h4="true" i_on_border="true" i_custom_color="#3267ad" h2_el_class="nomargin" h4_el_class="letter-spacing " css=".vc_custom_1520779883539{margin-top: -10px !important;}"]Toll-free hotline.
7 days a week from 10.00 a.m. to 6.00 p.m.[/vc_cta][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row full_width="stretch_row_content" css=".vc_custom_1520780049899{margin-top: 100px !important;padding-right: 50px !important;padding-left: 50px !important;}"][vc_column][deux_product_tabs per_page="8" columns="4" load_more="yes"][/vc_column][/vc_row][vc_row css=".vc_custom_1520780412612{margin-top: 100px !important;padding-right: 0px !important;padding-left: 0px !important;}"][vc_column][deux_product_slider2 ids="103, 99, 108, 112"][/vc_column][/vc_row][vc_row css=".vc_custom_1520781506358{margin-top: 150px !important;}"][vc_column][deux_post_image][/vc_column][/vc_row]
CONTENT;
  
    vc_add_default_templates( $data );
}