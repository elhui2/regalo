<?php
/**
 * Plugin Name: Deux Shortcode
 * Plugin URI: http://qedqod.com/deux
 * Description: A collection of extra elements for Visual Composer.
 * Author: QedQod
 * Author URI: http://qedqod.com/
 * Version: 1.0.7
 * Text Domain: deux
 * License: GPLv2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Deux_Plugin_Shortcode
 */
final class Deux_Plugin_Shortcode {
	
	public static function init(){
		static $instance = null;

		if ( is_null( $instance ) ) {
			$instance = new self;
			$instance->define_constants();
			$instance->wrap_files();
		}

		return $instance;
	}

	/**
	 * Wrap all files to this one punch
	 * @return void
	 */
	public function wrap_files()
	{
		add_action( 'plugins_loaded', array( $this, 'load_files' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_script' ));

		/* Make text widgets and term descriptions shortcode aware. */
	    add_filter( 'widget_text', 'do_shortcode' );
	    add_filter( 'term_description', 'do_shortcode' );
	    add_filter( 'the_excerpt', 'do_shortcode');
		add_action( 'init', array( 'Deux_Shortcodes', 'init' ), 50 );
		add_action( 'vc_after_init', array( 'Deux_VC', 'init' ), 50 );


	    /*filter product post*/
		add_filter( 'post_class', array( $this, 'product_class' ), 10, 3 );
		
		/*text domain*/
		load_plugin_textdomain( 'deux', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );

		
	}
	/**
	 * Defines constants
	 */
	public function define_constants() {
		define( 'DEUX_ADDONS_DIR', plugin_dir_path( __FILE__ ) );
		define( 'DEUX_ADDONS_URL', plugin_dir_url( __FILE__ ) );
	}

	/**
	 * Load files
	 */
	public function load_files() {
		require_once 'inc/shortcodes/outputshortcodeinterface.php';
		require_once 'inc/shortcodes/class-wp-shortcode-ui.php';
		require_once 'inc/shortcodes/class-shortcodes.php';

		require_once 'inc/shortcodes/banner-grid.php';
		require_once 'inc/shortcodes/banner.php';
		require_once 'inc/shortcodes/banner2.php';
		require_once 'inc/shortcodes/banner3.php';
		require_once 'inc/shortcodes/banner4.php';
		require_once 'inc/shortcodes/button.php';
		require_once 'inc/shortcodes/contact-box.php';
		require_once 'inc/shortcodes/countdown.php';
		require_once 'inc/shortcodes/credit-card.php';
		require_once 'inc/shortcodes/map.php';
		require_once 'inc/shortcodes/message-box.php';
		require_once 'inc/shortcodes/partner.php';
		require_once 'inc/shortcodes/post-grid.php';
		require_once 'inc/shortcodes/post-image.php';
		require_once 'inc/shortcodes/pricing-table.php';
		require_once 'inc/shortcodes/team-member.php';
		require_once 'inc/shortcodes/testimonial.php';

		if (class_exists('WooCommerce')) {
			require_once 'inc/shortcodes/product-carousel.php';
			require_once 'inc/shortcodes/product-grid.php';
			require_once 'inc/shortcodes/product-slider1.php';
			require_once 'inc/shortcodes/product-slider2.php';
			require_once 'inc/shortcodes/product-tabs.php';
			require_once 'inc/shortcodes/product.php';
		}

		require_once 'inc/user.php';
		require_once 'inc/class-vc.php';
		
		require_once 'inc/share.php';

		require_once 'inc/vc_templates.php';
		
	}

	/**
	 * Load scripts
	 */
	function enqueue_script() {
		global $post;

		$deux_map = is_page() || is_single() ? has_shortcode( $post->post_content, 'deux_map' ) : false;
	 
		wp_register_script( 'jquery-countdown', DEUX_ADDONS_URL . 'assets/js/jquery.countdown.js', array( 'jquery' ), '2.0.4', true );
		wp_register_script( 'jquery-circle-progress', DEUX_ADDONS_URL . 'assets/js/circle-progress.js', array( 'jquery' ), '1.1.3', true );
		wp_register_script( 'modernizr', DEUX_ADDONS_URL . 'assets/js/modernizr.js', array( 'jquery' ), '', true );

		wp_enqueue_script( 'deux-shortcodes', DEUX_ADDONS_URL . 'assets/js/shortcodes.js', array(
			'wp-util',
			'jquery-countdown',
			'jquery-circle-progress',
			'modernizr',
		), '1.0.0', true );

		if( $deux_map ) {
			wp_enqueue_script( 'deux-map', DEUX_ADDONS_URL . 'assets/js/map.js', array(), '1.0.0', true );
		}
	}

	/**
	 * Add classes to products which are inside loop of shortcodes
	 *
	 * @param array  $classes
	 * @param string $class
	 * @param int    $post_id
	 *
	 * @return array
	 */
	function product_class( $classes, $class, $post_id ) {
		if ( ! $post_id || get_post_type( $post_id ) !== 'product' || is_single( $post_id ) ) {
			return $classes;
		}

		global $woocommerce_loop;
		$accept_products = array(
			'deux_product_grid',
			'deux_ajax_products',
		);

		if ( ! isset( $woocommerce_loop['name'] ) || ! in_array( $woocommerce_loop['name'], $accept_products ) ) {
			return $classes;
		}

		// Add class for new products
		$newness = get_theme_mod( 'product_newness', false );
		if ( $newness && ( time() - ( 60 * 60 * 24 * $newness ) ) < strtotime( get_the_time( 'Y-m-d' ) ) ) {
			$classes[] = 'new';
		}

		return $classes;
	}
}

Deux_Plugin_Shortcode::init();
