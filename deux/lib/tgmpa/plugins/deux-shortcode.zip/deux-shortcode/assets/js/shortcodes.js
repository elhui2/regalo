jQuery( document ).ready( function ( $ ) {
	'use strict';

	/**
	 * Handle filter
	 */
	$( '.deux-product-grid.filterable' ).on( 'click', '.product-filter li', function ( e ) {
		e.preventDefault();
		e.stopPropagation();

		var $this = $( this ),
			$grid = $this.closest( '.deux-product-grid' ),
			$products = $grid.find( '.products' );

		if ( $this.hasClass( 'active' ) ) {
			return;
		}

		var offset_toolbar = $(this).offset().top - 60;

		$("html").velocity("scroll", { offset: offset_toolbar, mobileHA: false });
		
		$this.addClass( 'active' ).siblings( '.active' ).removeClass( 'active' );

	 
		var filter = $this.attr( 'data-filter' ),
			$container = $grid.find( '.products-grid' ),
			$container_height = $container.parent().height() * 2;;


		filter = filter.replace( /\./g, '' );
		filter = filter.replace( /product_cat-/g, '' );
		
		if (filter == 'all') {
			filter = ''
		}	

		var data = {
			columns  : $grid.data( 'columns' ),
			per_page : $grid.data( 'per_page' ),
			load_more: $grid.data( 'load_more' ),
			type     : '',
			nonce    : $grid.data( 'nonce' )
		};

		if ( $grid.hasClass( 'filter-by-group' ) ) {
			data.type = filter;
		} else {
			data.category = filter;
		}

		$container.velocity({ opacity: .3 }, { duration: 300 });
		
		$container.prev( '.filter-loading-icon' ).velocity({ opacity: 1 }, { duration: 300,  display: 'block' });

		$container.parent().css('height', $container_height);

		$container.find( '.ajax-navigation' ).remove();

			
		wp.ajax.send( 'deux_load_products', {
			data   : data,
			success: function ( response ) {

				$container.prev( '.filter-loading-icon' ).hide('0');

				setTimeout(function(){ 

					$container.find('.woocommerce').remove(); 

				}, 100);

				setTimeout(function(){
					$container.velocity({ opacity: 1 }, { duration: 300 }); 
					$( response ).find( 'ul.products > li' ).addClass( 'product' );

					$container.append( response );

					$( '.product-images__slider' , $container).owlCarousel( {
						items: 1,
						lazyLoad: true,
						dots: true,
						nav: false,
						rtl: deuxData.isRTL == '1',
					} );

					$grid.find('ul.products').imagesLoaded( function () {
					 	AOS.init({
					 		duration: 1000,
					 		disable: "mobile"
					 	});
					} );

				 	$container.find('.product').each(function(index){
				 		var grid = Math.floor($container.width() / $container.find('.product').width()),
				 		delayNumber = (index % grid) * 200;
				 		$(this).find('.aos-item').attr('data-aos-delay', delayNumber);
				 	});
				}, 200);

				setTimeout(function(){ $container.parent().css('height', 'auto');}, 300);

			}
		} );
	} );

	/**
	 * Ajax load more products
	 */
	$( document.body ).on( 'click', '.ajax-load-products', function ( e ) {
		e.preventDefault();
		var $el = $( this ),
			page = $el.data( 'page' );

		if ( $el.hasClass( 'loading' ) ) {
			return;
		}

		$el.parent().addClass( 'loading' );

		wp.ajax.send( 'deux_load_products', {
			data   : {
				page    : page,
				columns : $el.data( 'columns' ),
				per_page: $el.data( 'per_page' ),
				category: $el.data( 'category' ),
				type    : $el.data( 'type' ),
				nonce   : $el.data( 'nonce' )
			},
			success: function ( data ) {
				$el.data( 'page', page + 1 ).attr( 'page', page + 1 );
				$el.parent().removeClass( 'loading' );

				var $data = $( data ),
					$products = $data.find( 'ul.products > li' ),
					$button = $data.find( '.ajax-load-products' ),
					$container = $el.closest( '.deux-products' ),
					$grid = $container.find( 'ul.products' );

				// If has products
				if ( $products.length ) {
					// Add classes before append products to grid
					$products.addClass( 'product' );
					$grid.append( $products );

					$( '.product-images__slider' , $products).owlCarousel( {
						items: 1,
						lazyLoad: true,
						dots: true,
						nav: false,
						rtl: deuxData.isRTL == '1',
					} );

					$container.find('ul.products').imagesLoaded( function () {
						AOS.init({
							duration: 1000,
							disable: "mobile"
						});
					} );

					$container.find('.product').each(function(index){
				 		var grid = Math.floor($container.width() / $container.find('.product').width()),
				 		delayNumber = (index % grid) * 200;
				 		$(this).find('.aos-item').attr('data-aos-delay', delayNumber);
				 	});

					if ( $button.length ) {
						$el.replaceWith( $button );
					} else {
						$el.slideUp();
					}
				}
			}
		} );
	} );

	/**
	 *  Countdown
	 */
	$( '.deux-countdown' ).each( function () {
		var $el = $( this ),
			$timers = $el.find( '.timers' ),
			output = '';
			$timers.countdown( $timers.data( 'date' ), function ( event ) {
			output = '';
			var day = event.strftime( '%D' );
			for ( var i = 0; i < day.length; i++ ) {
				output += '<span>' + day[i] + '</span>';
			}
			$timers.find( '.day' ).html( output );

			output = '';
			var hour = event.strftime( '%H' );
			for ( i = 0; i < hour.length; i++ ) {
				output += '<span>' + hour[i] + '</span>';
			}
			$timers.find( '.hour' ).html( output );

			output = '';
			var minu = event.strftime( '%M' );
			for ( i = 0; i < minu.length; i++ ) {
				output += '<span>' + minu[i] + '</span>';
			}
			$( this ).find( '.min' ).html( output );

			output = '';
			var secs = event.strftime( '%S' );
			for ( i = 0; i < secs.length; i++ ) {
				output += '<span>' + secs[i] + '</span>';
			}
			$timers.find( '.secs' ).html( output );
		} );
	} );

	/**
	 * Init banner grid layout 5
	 */
	$( '.deux-banner-grid-5' ).each( function () {
		var $items = $( this ).children(),
			chucks = [];

		$items.each( function () {
			var $item = $( this );

			$item.css( 'background-image', function () {
				return 'url(' + $item.find( 'img' ).attr( 'src' ) + ')';
			} );
		} );

		for ( var i = 0; i < $items.length; i += 5 ) {
			var chuck = $items.splice( i, i + 5 ),
				$chuck = $( chuck );

			$chuck.wrapAll( '<div class="banners-wrap"/>' );
			$chuck.filter( ':eq(0)' ).wrapAll( '<div class="banners banners-column-1"/>' );
			$chuck.filter( ':eq(1), :eq(2)' ).wrapAll( '<div class="banners banners-column-2"/>' );
			$chuck.filter( ':gt(2)' ).wrapAll( '<div class="banners banners-column-3"/>' );

			chucks.push( chuck );
		}
	} );

	/**
	 * Init charts
	 */
	$( '.deux-chart' ).circleProgress( {
		emptyFill : 'rgba(0,0,0,0)',
		startAngle: -Math.PI / 2
	} );

	/**
	 * Close message box
	 */
	$( document.body ).on( 'click', '.deux-message-box .close', function ( e ) {
		e.preventDefault();

		$( this ).parent().fadeOut( 'slow' );
	} );

 
	$('.deux-button.button-type-custom').each( function(){
			var element = $(this),
				elementBg = element.attr('data-bg'),
				elementText = element.attr('data-text'),
				elementBgHover = element.attr('data-bg-hover'),
				elementTextHover = element.attr('data-text-hover');
			

			element.hover(function() {
				element.css({
					'background-color': elementBgHover,
					'color': elementTextHover
				});
			}, function() {
				 element.css({
					'background-color': elementBg,
					'color': elementText
				});
			});
	});

	$('#ps-container').each(function() {
		var $container = $(this),
		$contentwrapper = $container.children( 'div.ps-contentwrapper' ),
		// the items (description elements for the slides/products)
		$items = $contentwrapper.children( 'div.ps-content' ),
		itemsCount = $items.length,
		$slidewrapper = $container.children( 'div.ps-slidewrapper' ),
		// the slides (product images)
		$slidescontainer = $slidewrapper.find( 'div.ps-slides' ),
		$slides = $slidescontainer.children( 'div' ),
		// navigation arrows
		$navprev = $slidewrapper.find( 'nav > a.ps-prev' ),
		$navnext = $slidewrapper.find( 'nav > a.ps-next' ),
		// current index for items and slides
		current = 0,
		// checks if the transition is in progress
		isAnimating = false,
		// support for CSS transitions
		support = Modernizr.csstransitions,
		// transition end event
		// https://github.com/twitter/bootstrap/issues/2870
		transEndEventNames = {
			'WebkitTransition' : 'webkitTransitionEnd',
			'MozTransition' : 'transitionend',
			'OTransition' : 'oTransitionEnd',
			'msTransition' : 'MSTransitionEnd',
			'transition' : 'transitionend'
		},
		// its name
		transEndEventName = transEndEventNames[ Modernizr.prefixed( 'transition' ) ],

			init = function() {
				// show first item
				var $currentItem = $items.eq( current ),
					$currentSlide = $slides.eq( current ),
					initCSS = {
						top : 0,
						zIndex : 999
					};

				$currentItem.css( initCSS );
				$currentSlide.css( initCSS );
				
				// update nav images
				updateNavImages();

				// initialize some events
				initEvents();

			},
			updateNavImages = function() {

				// updates the background image for the navigation arrows
				var configPrev = ( current > 0 ) ? $slides.eq( current - 1 ).css( 'background-image' ) : $slides.eq( itemsCount - 1 ).css( 'background-image' ),
					configNext = ( current < itemsCount - 1 ) ? $slides.eq( current + 1 ).css( 'background-image' ) : $slides.eq( 0 ).css( 'background-image' );

				$navprev.css( 'background-image', configPrev );
				$navnext.css( 'background-image', configNext );

			},
			initEvents = function() {

				$navprev.on( 'click', function( event ) {

					if( !isAnimating ) {
						
						slide( 'prev' );
					
					}
					return false;

				} );

				$navnext.on( 'click', function( event ) {

					if( !isAnimating ) {
						
						slide( 'next' );
					
					}
					return false;

				} );

				// transition end event
				$items.on( transEndEventName, removeTransition );
				$slides.on( transEndEventName, removeTransition );
				
			},
			removeTransition = function() {

				isAnimating = false;
				$(this).removeClass('ps-move');

			},
			slide = function( dir ) {

				isAnimating = true;

				var $currentItem = $items.eq( current ),
					$currentSlide = $slides.eq( current );

				// update current value
				if( dir === 'next' ) {

					( current < itemsCount - 1 ) ? ++current : current = 0;

				}
				else if( dir === 'prev' ) {

					( current > 0 ) ? --current : current = itemsCount - 1;

				}
					// new item that will be shown
				var $newItem = $items.eq( current ),
					// new slide that will be shown
					$newSlide = $slides.eq( current );

				// position the new item up or down the viewport depending on the direction
				$newItem.css( {
					top : ( dir === 'next' ) ? '-100%' : '100%',
					zIndex : 999
				} );
				
				$newSlide.css( {
					top : ( dir === 'next' ) ? '100%' : '-100%',
					zIndex : 999
				} );

				setTimeout( function() {

					// move the current item and slide to the top or bottom depending on the direction 
					$currentItem.addClass( 'ps-move' ).css( {
						top : ( dir === 'next' ) ? '100%' : '-100%',
						zIndex : 1
					} );

					$currentSlide.addClass( 'ps-move' ).css( {
						top : ( dir === 'next' ) ? '-100%' : '100%',
						zIndex : 1
					} );

					// move the new ones to the main viewport
					$newItem.addClass( 'ps-move' ).css( 'top', 0 );
					$newSlide.addClass( 'ps-move' ).css( 'top', 0 );

					// if no CSS transitions set the isAnimating flag to false
					if( !support ) {

						isAnimating = false;

					}

				}, 0 );

				// update nav images
				updateNavImages();

			};

		  init();
		
	});
} );
