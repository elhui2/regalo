<?php
/**
 * Plugin Name: Deux Portfolio
 * Plugin URI: http://qedqod.com/deux
 * Description: Deux portfolio integration.
 * Author: QedQod
 * Author URI: http://qedqod.com/
 * Version: 1.0.0
 * Text Domain: deux
 * License: GPLv2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

define( 'DEUX_PORTFOLIO_DIR', plugin_dir_path( __FILE__ ) );
define( 'DEUX_PORTFOLIO_URL', plugin_dir_url( __FILE__ ) );

/**
 * 
 */
class Deux_Portfolio {
	
	public static function init() {
		static $instance = null;

		if ( is_null( $instance ) ) {
			$instance = new self;
			$instance->hooks();
		}

		return $instance;
	}

	function hooks() {
		add_action( 'plugins_loaded', array( $this, 'includes' ) );
		add_action( 'init', array( 'Deux_Register_Portfolio', 'init' ) );
	}

	function includes() {
		require_once DEUX_PORTFOLIO_DIR . 'includes/register-portfolio.php';
		require_once DEUX_PORTFOLIO_DIR . 'includes/customizer.php';
	}

}

Deux_Portfolio::init();