<?php
/**
 * Integrate portfolio customizer setting with theme.
 */

if ( ! class_exists( 'Kirki' ) ) return;

// Setting fields for Portfolio
if ( get_option( 'deux_portfolio' ) ) {

	Kirki::add_section( 'portfolio-section', array(
		'title'    => esc_html__( 'Portfolio', 'deux' ),
		'priority' => 85,
		'panel'    => 'theme_options',
	) );

	$options[] = array( 
		'settings'    => 'divider-portfolio-header',
		'type'        => 'custom',
		'section'     => 'portfolio-section',
		'default'     => '<h4 class="customize-subtitle">'. esc_html__('Portfolio Page Header', 'deux') .'</h4>',
	);
	
	$options['portfolio_page_header_bg'] = array( 
		'settings' => 'portfolio_page_header_bg'        ,
			'type'            => 'image',
			'label'           => esc_html__( 'Portfolio Page Header Image', 'deux' ),
			'description'     => esc_html__( 'The background image for portfolio page header', 'deux' ),
			'section'         => 'portfolio-section',
			'default'         => '',
	);

	$options['portfolio_page_header_text_color'] = array( 
		'settings' => 'portfolio_page_header_text_color',
			'type'            => 'select',
			'label'           => esc_html__( 'Portfolio Page Header Text Color', 'deux' ),
			'section'         => 'portfolio-section',
			'default'         => 'dark',
			'choices'         => array(
				'dark'  => esc_html__( 'Dark', 'deux' ),
				'light' => esc_html__( 'Light', 'deux' ),
			),
	);

	// Portfolio archive
	$options[] = array( 
		'settings'    => 'divider-portfolio-archive',
		'type'        => 'custom',
		'section'     => 'portfolio-section',
		'default'     => '<h4 class="customize-subtitle">'. esc_html__('Portfolio Archive', 'deux') .'</h4>'
	);

	$options['portfolio_filter'] = array( 
		'settings' => 'portfolio_filter'                ,
			'type'        => 'toggle',
			'label'       => esc_html__( 'Portfolio Filter', 'deux' ),
			'description' => esc_html__( 'Enable portfolio filter on the archive page', 'deux' ),
			'section'     => 'portfolio-section',
			'default'     => true,
	);

	$options['portfolio_style'] = array( 
		'settings' => 'portfolio_style'                 ,
			'type'    => 'select',
			'label'   => esc_html__( 'Portfolio Style', 'deux' ),
			'section' => 'portfolio-section',
			'default' => 'classic',
			'choices' => array(
				'classic'   => esc_html__( 'Classic', 'deux' ),
				'fullwidth' => esc_html__( 'Full Width', 'deux' ),
				'masonry'   => esc_html__( 'Masonry', 'deux' ),
			),
	);

	// Portfolio single
	$options[] = array( 
		'settings'    => 'divider-portfolio-single',
		'type'        => 'custom',
		'section'     => 'portfolio-section',
		'default'     => '<h4 class="customize-subtitle">'. esc_html__('Portfolio Single', 'deux') .'</h4>'
	);

	$options['project_share'] = array( 
		'settings' => 'project_share'                   ,
			'type'        => 'toggle',
			'label'       => esc_html__( 'Social Share', 'deux' ),
			'description' => esc_html__( 'Enable social sharing icons', 'deux' ),
			'section'     => 'portfolio-section',
			'default'     => false,
	);

	$options['project_navigation'] = array( 
		'settings' => 'project_navigation'              ,
			'type'        => 'toggle',
			'label'       => esc_html__( 'Single Navigation', 'deux' ),
			'description' => esc_html__( 'Enable next/previous navigation', 'deux' ),
			'section'     => 'portfolio-section',
			'default'     => true,
	);

	$options['project_nav_text_next'] = array( 
		'settings' => 'project_nav_text_next'           ,
			'type'            => 'text',
			'label'           => esc_html__( 'Next Link Text', 'deux' ),
			'section'         => 'portfolio-section',
			'default'         => esc_html__( 'Next Portfolio', 'deux' ),
			'active_callback' => array(
				array(
					'setting'  => 'project_navigation',
					'operator' => '==',
					'value'    => true,
				),
			),
	);

	$options['project_nav_text_prev'] = array( 
		'settings' => 'project_nav_text_prev'           ,
			'type'            => 'text',
			'label'           => esc_html__( 'Prev Link Text', 'deux' ),
			'section'         => 'portfolio-section',
			'default'         => esc_html__( 'Previous Portfolio', 'deux' ),
			'active_callback' => array(
				array(
					'setting'  => 'project_navigation',
					'operator' => '==',
					'value'    => true,
				),
			),
	);

	foreach ( $options as $option ) {
		Kirki::add_field( 'deux', $option );
	}
	
}